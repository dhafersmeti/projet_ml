"""
Etape 1 : analyse exploratoire des donnees (EDA).

Objectifs :
  - decrire le jeu de donnees (taille, types, valeurs manquantes),
  - mesurer le desequilibre des classes,
  - visualiser les correlations entre variables (heatmap),
  - comparer les distributions des variables selon la classe.

Sorties :
  figures/01_distribution_classes.png
  figures/01_heatmap_correlations.png
  figures/01_boxplots_variables.png
  results/01_description_donnees.json
  results/01_statistiques_descriptives.csv
"""

import json
import os
import sys

import matplotlib

matplotlib.use("Agg")  # rendu sans fenetre graphique (execution en ligne de commande)
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# Permet d'importer config.py situe dans le meme dossier
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (NOM_CLASSES, charger_donnees, chemin_figure, chemin_result,
                    creer_dossiers, fixer_graines)


def main():
    fixer_graines()
    creer_dossiers()
    sns.set_theme(style="whitegrid")

    X, y, noms = charger_donnees()
    print("=" * 70)
    print("ETAPE 1 : EXPLORATION DES DONNEES")
    print("=" * 70)

    # ------------------------------------------------------------------
    # 1. Description generale
    # ------------------------------------------------------------------
    n_patients, n_variables = X.shape
    n_manquantes = int(X.isna().sum().sum())
    print(f"Nombre de patients   : {n_patients}")
    print(f"Nombre de variables  : {n_variables}")
    print(f"Valeurs manquantes   : {n_manquantes}")
    print(f"Types de variables   : {X.dtypes.unique().tolist()} (toutes numeriques)")

    # Statistiques descriptives sauvegardees pour le rapport
    X.describe().T.to_csv(chemin_result("01_statistiques_descriptives.csv"))

    # ------------------------------------------------------------------
    # 2. Desequilibre des classes
    # ------------------------------------------------------------------
    effectifs = y.value_counts().sort_index()
    proportions = y.value_counts(normalize=True).sort_index()
    print("\nRepartition des classes (1 = malin, classe positive) :")
    for classe in effectifs.index:
        print(f"  {NOM_CLASSES[classe]:6s} : {effectifs[classe]:4d} patients "
              f"({100 * proportions[classe]:.1f} %)")
    ratio = effectifs[0] / effectifs[1]
    print(f"Ratio benin / malin : {ratio:.2f}  (desequilibre modere)")

    fig, ax = plt.subplots(figsize=(5, 4))
    couleurs = ["#4C72B0", "#C44E52"]
    ax.bar([NOM_CLASSES[c] for c in effectifs.index], effectifs.values, color=couleurs)
    for i, v in enumerate(effectifs.values):
        ax.text(i, v + 5, f"{v} ({100 * proportions.iloc[i]:.1f} %)", ha="center")
    ax.set_ylabel("Nombre de patients")
    ax.set_title("Répartition des classes (déséquilibre)")
    ax.set_ylim(0, effectifs.max() * 1.15)
    fig.tight_layout()
    fig.savefig(chemin_figure("01_distribution_classes.png"), dpi=150)
    plt.close(fig)

    # ------------------------------------------------------------------
    # 3. Correlations entre variables (heatmap)
    # ------------------------------------------------------------------
    corr = X.corr()
    fig, ax = plt.subplots(figsize=(14, 12))
    masque = np.triu(np.ones_like(corr, dtype=bool))  # on n'affiche que le triangle inferieur
    sns.heatmap(corr, mask=masque, cmap="coolwarm", center=0, vmin=-1, vmax=1,
                square=True, linewidths=0.3, cbar_kws={"shrink": 0.6}, ax=ax)
    ax.set_title("Matrice de corrélation (Pearson) des 30 variables")
    fig.tight_layout()
    fig.savefig(chemin_figure("01_heatmap_correlations.png"), dpi=130)
    plt.close(fig)

    # Paires de variables tres correlees (|r| > 0.9) : signale la redondance
    paires = []
    for i in range(n_variables):
        for j in range(i + 1, n_variables):
            r = corr.iloc[i, j]
            if abs(r) > 0.9:
                paires.append((noms[i], noms[j], round(float(r), 3)))
    paires.sort(key=lambda t: -abs(t[2]))
    print(f"\nPaires de variables avec |r| > 0.9 : {len(paires)}")
    for a, b, r in paires[:8]:
        print(f"  {a:25s} ~ {b:25s} r = {r}")

    # Correlation de chaque variable avec la cible (point-biserial = Pearson ici)
    corr_cible = X.corrwith(y).sort_values(key=np.abs, ascending=False)
    print("\nVariables les plus correlees avec la cible (malin) :")
    print(corr_cible.head(10).round(3).to_string())
    corr_cible.rename("correlation_avec_cible").to_csv(
        chemin_result("01_correlation_cible.csv"))

    # ------------------------------------------------------------------
    # 4. Distributions des variables les plus discriminantes selon la classe
    # ------------------------------------------------------------------
    top_vars = corr_cible.head(8).index.tolist()
    df = X[top_vars].copy()
    df["classe"] = y.map(NOM_CLASSES)
    df_long = df.melt(id_vars="classe", var_name="variable", value_name="valeur")

    g = sns.catplot(data=df_long, x="classe", y="valeur", col="variable", kind="box",
                    col_wrap=4, sharey=False, height=2.8, aspect=1.0,
                    palette={"Bénin": "#4C72B0", "Malin": "#C44E52"}, hue="classe",
                    legend=False)
    g.set_titles("{col_name}")
    g.figure.suptitle("Distribution des 8 variables les plus liées à la cible", y=1.02)
    g.savefig(chemin_figure("01_boxplots_variables.png"), dpi=150)
    plt.close(g.figure)

    # ------------------------------------------------------------------
    # 5. Sauvegarde d'un resume JSON (reutilise par 03_modeles.py)
    # ------------------------------------------------------------------
    resume = {
        "n_patients": int(n_patients),
        "n_variables": int(n_variables),
        "n_valeurs_manquantes": n_manquantes,
        "n_benin": int(effectifs[0]),
        "n_malin": int(effectifs[1]),
        "pct_malin": round(100 * float(proportions[1]), 2),
        "n_paires_corr_sup_0_9": len(paires),
        "variables_plus_correlees_cible": top_vars,
    }
    with open(chemin_result("01_description_donnees.json"), "w", encoding="utf-8") as f:
        json.dump(resume, f, indent=2, ensure_ascii=False)

    print("\nFigures et resultats de l'EDA sauvegardes.")


if __name__ == "__main__":
    main()
