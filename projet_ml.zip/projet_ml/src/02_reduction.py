"""
Etape 2 : reduction de dimensionnalite et selection de variables.

Deux familles d'approches sont comparees :
  A. Analyse en composantes principales (ACP) : on cree de nouvelles variables
     (combinaisons lineaires) et on choisit le nombre de composantes a garder
     a partir de la variance expliquee cumulee.
  B. Selection de variables : on garde un sous-ensemble des 30 variables
     d'origine, par trois methodes :
       1. filtre par correlation (on retire une variable de chaque paire trop
          correlee, |r| > 0.9, pour limiter la redondance),
       2. regression logistique penalisee L1 (LASSO) : les coefficients nuls
          eliminent des variables,
       3. importance par foret aleatoire (importance moyenne par arbre).

Chaque strategie est ensuite evaluee par validation croisee stratifiee avec
une regression logistique dans un Pipeline (standardisation -> selection ->
modele) : les selections supervisees (LASSO, foret) et l'ACP sont refaites
dans chaque pli, ce qui evite un biais de selection optimiste. Pour le LASSO,
la force de penalite est choisie par la regle "un ecart-type".

Toutes les analyses sont faites UNIQUEMENT sur le jeu d'entrainement pour
eviter toute fuite d'information vers le jeu de test.

Sorties :
  figures/02_acp_variance_expliquee.png
  figures/02_acp_projection_2d.png
  figures/02_lasso_coefficients.png
  figures/02_importance_foret.png
  figures/02_comparaison_sous_ensembles.png
  results/02_reduction.json
  results/02_comparaison_sous_ensembles.csv
"""

import json
import os
import sys
import warnings

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LogisticRegression, LogisticRegressionCV
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (NOM_CLASSES, RANDOM_STATE, charger_donnees, chemin_figure,
                    chemin_result, creer_dossiers, fixer_graines,
                    separer_train_test)

# Avertissements sans consequence (futurs changements d'API, convergence liblinear)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)
from sklearn.exceptions import ConvergenceWarning  # noqa: E402

warnings.filterwarnings("ignore", category=ConvergenceWarning)

# Seuil de variance expliquee cumulee pour choisir le nombre de composantes
SEUIL_VARIANCE = 0.95


def analyse_acp(X_train_std, noms):
    """ACP sur les donnees standardisees ; renvoie le nombre de composantes a garder."""
    acp = PCA(random_state=RANDOM_STATE).fit(X_train_std)
    variance = acp.explained_variance_ratio_
    cumul = np.cumsum(variance)
    n_comp_95 = int(np.argmax(cumul >= SEUIL_VARIANCE) + 1)
    # Regle de Kaiser : composantes dont la valeur propre est > 1
    n_comp_kaiser = int(np.sum(acp.explained_variance_ > 1))

    print(f"Variance expliquee par les 5 premieres composantes : "
          f"{np.round(variance[:5], 3).tolist()}")
    print(f"Nombre de composantes pour {int(SEUIL_VARIANCE * 100)} % de variance : {n_comp_95}")
    print(f"Nombre de composantes selon la regle de Kaiser (valeur propre > 1) : {n_comp_kaiser}")

    # Figure : variance expliquee (barres) + cumul (courbe)
    fig, ax1 = plt.subplots(figsize=(8, 4.5))
    indices = np.arange(1, len(variance) + 1)
    ax1.bar(indices, variance, color="#4C72B0", alpha=0.8, label="Variance par composante")
    ax1.set_xlabel("Composante principale")
    ax1.set_ylabel("Part de variance expliquée")
    ax2 = ax1.twinx()
    ax2.plot(indices, cumul, color="#C44E52", marker="o", ms=3, label="Variance cumulée")
    ax2.axhline(SEUIL_VARIANCE, ls="--", color="gray")
    ax2.axvline(n_comp_95, ls=":", color="gray")
    ax2.text(n_comp_95 + 0.3, 0.5, f"{n_comp_95} composantes\n= {100 * cumul[n_comp_95 - 1]:.1f} %")
    ax2.set_ylabel("Variance cumulée")
    ax2.set_ylim(0, 1.02)
    ax1.set_title("ACP : variance expliquée et choix du nombre de composantes")
    lignes = ax1.get_legend_handles_labels()[0] + ax2.get_legend_handles_labels()[0]
    etiquettes = ax1.get_legend_handles_labels()[1] + ax2.get_legend_handles_labels()[1]
    ax1.legend(lignes, etiquettes, loc="center right")
    fig.tight_layout()
    fig.savefig(chemin_figure("02_acp_variance_expliquee.png"), dpi=150)
    plt.close(fig)

    return acp, n_comp_95, n_comp_kaiser, cumul


def projection_2d(acp, X_train_std, y_train):
    """Nuage de points des patients sur les deux premieres composantes."""
    Z = acp.transform(X_train_std)[:, :2]
    fig, ax = plt.subplots(figsize=(6.5, 5))
    for classe, couleur in [(0, "#4C72B0"), (1, "#C44E52")]:
        masque = (y_train.values == classe)
        ax.scatter(Z[masque, 0], Z[masque, 1], s=18, alpha=0.7, color=couleur,
                   label=NOM_CLASSES[classe])
    ax.set_xlabel(f"CP1 ({100 * acp.explained_variance_ratio_[0]:.1f} %)")
    ax.set_ylabel(f"CP2 ({100 * acp.explained_variance_ratio_[1]:.1f} %)")
    ax.set_title("Projection des patientes (train) sur les 2 premières composantes")
    ax.legend()
    fig.tight_layout()
    fig.savefig(chemin_figure("02_acp_projection_2d.png"), dpi=150)
    plt.close(fig)


def selection_par_correlation(X_train, seuil=0.9):
    """
    Filtre de redondance : on parcourt les variables et on retire celles dont la
    correlation absolue avec une variable deja conservee depasse le seuil.
    """
    corr = X_train.corr().abs()
    conservees = []
    for var in X_train.columns:
        if all(corr.loc[var, autre] <= seuil for autre in conservees):
            conservees.append(var)
    return conservees


def selection_par_lasso(X_train_std, y_train, noms):
    """
    Regression logistique penalisee L1 (LASSO).

    La force de la penalite (C, inverse de la regularisation) est choisie par
    validation croisee a 5 plis sur une grille logarithmique de 0.001 a 100.
    On applique la regle "un ecart-type" : au lieu du C qui maximise le score
    moyen, on retient le plus petit C (penalite la plus forte, donc le moins de
    variables) dont le score moyen reste a moins d'une erreur standard du
    meilleur score. Les variables a coefficient nul sont eliminees.

    Renvoie (variables conservees, coefficients, C retenu, C du meilleur score).
    """
    grille_C = np.logspace(-3, 2, 21)
    # l1_ratios=(1.0,) = penalite L1 pure (syntaxe scikit-learn >= 1.8)
    lasso_cv = LogisticRegressionCV(Cs=grille_C, l1_ratios=(1.0,), cv=5, solver="liblinear",
                                    scoring="average_precision", max_iter=2000,
                                    random_state=RANDOM_STATE)
    lasso_cv.fit(X_train_std, y_train)

    # scores_ : {classe : tableau (n_plis, n_C, n_l1_ratios)} -> on garde (n_plis, n_C)
    scores = np.asarray(list(lasso_cv.scores_.values())[0])[:, :, 0]
    moyenne = scores.mean(axis=0)
    erreur_standard = scores.std(axis=0, ddof=1) / np.sqrt(scores.shape[0])
    idx_meilleur = int(np.argmax(moyenne))
    seuil_score = moyenne[idx_meilleur] - erreur_standard[idx_meilleur]
    idx_1se = int(np.argmax(moyenne >= seuil_score))  # premier C (le plus petit) acceptable
    c_meilleur = float(grille_C[idx_meilleur])
    c_1se = float(grille_C[idx_1se])

    # Reajustement du LASSO au C retenu sur tout le train pour lire les coefficients
    lasso = LogisticRegression(l1_ratio=1.0, C=c_1se, solver="liblinear", max_iter=2000,
                               random_state=RANDOM_STATE).fit(X_train_std, y_train)
    coefs = pd.Series(np.ravel(lasso.coef_), index=noms)
    conservees = coefs[coefs != 0].index.tolist()
    print(f"LASSO : C du meilleur score = {c_meilleur:.4g} (score {moyenne[idx_meilleur]:.4f}), "
          f"C retenu par la regle un ecart-type = {c_1se:.4g} (score {moyenne[idx_1se]:.4f}), "
          f"{len(conservees)} variables conservees")

    fig, ax = plt.subplots(figsize=(8, 7))
    coefs_tries = coefs.reindex(coefs.abs().sort_values().index)
    couleurs = ["#C44E52" if c > 0 else "#4C72B0" for c in coefs_tries]
    ax.barh(coefs_tries.index, coefs_tries.values, color=couleurs)
    ax.axvline(0, color="black", lw=0.8)
    ax.set_xlabel("Coefficient (variables standardisées)")
    ax.set_title("Régression logistique L1 (LASSO) : coefficients\n"
                 "rouge = augmente le risque de malignité, bleu = le diminue, 0 = éliminée")
    fig.tight_layout()
    fig.savefig(chemin_figure("02_lasso_coefficients.png"), dpi=150)
    plt.close(fig)
    return conservees, coefs, c_1se, c_meilleur


def selection_par_foret(X_train, y_train, noms, n_garder=10):
    """Importance par foret aleatoire (diminution moyenne d'impurete)."""
    foret = RandomForestClassifier(n_estimators=500, random_state=RANDOM_STATE, n_jobs=-1)
    foret.fit(X_train, y_train)
    importances = pd.Series(foret.feature_importances_, index=noms).sort_values(ascending=False)
    conservees = importances.head(n_garder).index.tolist()

    fig, ax = plt.subplots(figsize=(8, 7))
    sns.barplot(x=importances.values, y=importances.index, color="#55A868", ax=ax)
    ax.axhline(n_garder - 0.5, ls="--", color="gray")
    ax.set_xlabel("Importance (diminution moyenne d'impureté)")
    ax.set_title(f"Importance des variables par forêt aléatoire ({n_garder} premières retenues)")
    fig.tight_layout()
    fig.savefig(chemin_figure("02_importance_foret.png"), dpi=150)
    plt.close(fig)
    return conservees, importances


def evaluer_sous_ensemble(X_train, y_train, cv, variables=None, selecteur=None,
                          n_comp_acp=None):
    """
    Evalue une strategie de reduction par validation croisee, avec une
    regression logistique comme modele. Tout est place dans un Pipeline
    (standardisation -> [selecteur supervise] -> [ACP] -> modele), donc la
    selection de variables et l'ACP sont REFAITES dans chaque pli, uniquement
    sur la partie entrainement du pli : aucune fuite vers la partie validation.

    variables  : liste de colonnes a conserver (filtre non supervise, ex. correlation)
    selecteur  : transformateur SelectFromModel (LASSO ou foret), ajuste par pli
    n_comp_acp : nombre de composantes d'ACP (None = pas d'ACP)
    """
    etapes = [("scaler", StandardScaler())]
    if selecteur is not None:
        etapes.append(("selection", selecteur))
    if n_comp_acp is not None:
        etapes.append(("acp", PCA(n_components=n_comp_acp, random_state=RANDOM_STATE)))
    etapes.append(("modele", LogisticRegression(max_iter=5000, random_state=RANDOM_STATE)))
    pipeline = Pipeline(etapes)
    X_utilise = X_train if variables is None else X_train[variables]
    scores = cross_validate(pipeline, X_utilise, y_train, cv=cv,
                            scoring=["roc_auc", "average_precision", "recall", "f1"],
                            n_jobs=-1)
    return {m: (scores[f"test_{m}"].mean(), scores[f"test_{m}"].std())
            for m in ["roc_auc", "average_precision", "recall", "f1"]}


def main():
    fixer_graines()
    creer_dossiers()
    sns.set_theme(style="whitegrid")

    print("=" * 70)
    print("ETAPE 2 : REDUCTION DE DIMENSIONNALITE ET SELECTION DE VARIABLES")
    print("=" * 70)

    X, y, noms = charger_donnees()
    X_train, X_test, y_train, y_test = separer_train_test(X, y)
    print(f"Jeu d'entrainement : {len(X_train)} patients (le test de {len(X_test)} "
          f"patients n'est pas utilise ici)")

    # Standardisation (ajustee sur le train seulement) : indispensable avant l'ACP
    scaler = StandardScaler().fit(X_train)
    X_train_std = scaler.transform(X_train)

    # ---- A. ACP ------------------------------------------------------
    print("\n--- A. Analyse en composantes principales ---")
    acp, n_comp_95, n_comp_kaiser, cumul = analyse_acp(X_train_std, noms)
    projection_2d(acp, X_train_std, y_train)

    # ---- B. Selection de variables ------------------------------------
    print("\n--- B. Selection de variables ---")
    vars_corr = selection_par_correlation(X_train)
    print(f"Filtre par correlation (|r| <= 0.9) : {len(vars_corr)} variables conservees")
    vars_lasso, coefs_lasso, c_1se, c_meilleur = selection_par_lasso(X_train_std, y_train, noms)
    vars_foret, importances = selection_par_foret(X_train, y_train, noms, n_garder=10)
    print(f"Foret aleatoire : 10 variables les plus importantes = {vars_foret[:5]} ...")

    # ---- C. Comparaison des sous-ensembles par validation croisee ------
    # Les selections supervisees (LASSO, foret) sont refaites dans chaque pli via
    # SelectFromModel ; les listes ci-dessus (calculees sur tout le train) ne
    # servent qu'a decrire la selection finale et a nommer les sous-ensembles.
    print("\n--- C. Comparaison des sous-ensembles (regression logistique, CV 5 plis, "
          "selection refaite dans chaque pli) ---")
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    selecteur_lasso = SelectFromModel(LogisticRegression(l1_ratio=1.0, C=c_1se, solver="liblinear",
                                                         max_iter=2000, random_state=RANDOM_STATE))
    selecteur_foret = SelectFromModel(RandomForestClassifier(n_estimators=500, n_jobs=1,
                                                             random_state=RANDOM_STATE),
                                      max_features=10, threshold=-np.inf)
    # nom -> (variables conservees a priori, selecteur par pli, n composantes ACP, dimension)
    sous_ensembles = {
        "Toutes (30)": (None, None, None, len(noms)),
        f"ACP ({n_comp_95} comp.)": (None, None, n_comp_95, n_comp_95),
        f"Corrélation ({len(vars_corr)})": (vars_corr, None, None, len(vars_corr)),
        f"LASSO ({len(vars_lasso)})": (None, selecteur_lasso, None, len(vars_lasso)),
        "Forêt (10)": (None, selecteur_foret, None, 10),
    }
    lignes = []
    for nom, (variables, selecteur, n_comp, n_dim) in sous_ensembles.items():
        res = evaluer_sous_ensemble(X_train, y_train, cv, variables=variables,
                                    selecteur=selecteur, n_comp_acp=n_comp)
        lignes.append({"sous_ensemble": nom, "n_dimensions": n_dim,
                       **{f"{m}_moyenne": round(v[0], 4) for m, v in res.items()},
                       **{f"{m}_ecart_type": round(v[1], 4) for m, v in res.items()}})
        print(f"  {nom:22s} dim={n_dim:2d}  ROC-AUC={res['roc_auc'][0]:.4f}  "
              f"PR-AUC={res['average_precision'][0]:.4f}  Rappel={res['recall'][0]:.4f}  "
              f"F1={res['f1'][0]:.4f}")
    comparaison = pd.DataFrame(lignes)
    comparaison.to_csv(chemin_result("02_comparaison_sous_ensembles.csv"), index=False)

    # Figure de comparaison
    fig, ax = plt.subplots(figsize=(8, 4.5))
    metriques = ["roc_auc", "average_precision", "recall", "f1"]
    etiquettes = ["ROC-AUC", "PR-AUC", "Rappel", "F1"]
    largeur = 0.2
    x = np.arange(len(comparaison))
    for i, (m, e) in enumerate(zip(metriques, etiquettes)):
        ax.bar(x + (i - 1.5) * largeur, comparaison[f"{m}_moyenne"], largeur,
               yerr=comparaison[f"{m}_ecart_type"], capsize=2, label=e)
    ax.set_xticks(x)
    ax.set_xticklabels(comparaison["sous_ensemble"], rotation=15)
    ax.set_ylim(0.85, 1.01)
    ax.set_ylabel("Score en validation croisée (moyenne +/- écart-type)")
    ax.set_title("Comparaison des sous-ensembles de variables (régression logistique)")
    ax.legend(loc="lower right", ncol=4)
    fig.tight_layout()
    fig.savefig(chemin_figure("02_comparaison_sous_ensembles.png"), dpi=150)
    plt.close(fig)

    # ---- D. Sauvegarde pour les etapes suivantes ----------------------
    resume = {
        "seuil_variance_acp": SEUIL_VARIANCE,
        "n_composantes_acp_95": n_comp_95,
        "n_composantes_kaiser": n_comp_kaiser,
        "variance_cumulee_2_composantes": round(float(cumul[1]), 4),
        "variance_cumulee_n_comp_95": round(float(cumul[n_comp_95 - 1]), 4),
        "variables_correlation": vars_corr,
        "lasso_C_1se": c_1se,
        "lasso_C_meilleur": c_meilleur,
        "variables_lasso": vars_lasso,
        "variables_foret": vars_foret,
        "comparaison": lignes,
    }
    with open(chemin_result("02_reduction.json"), "w", encoding="utf-8") as f:
        json.dump(resume, f, indent=2, ensure_ascii=False)
    print("\nResultats de la reduction sauvegardes dans results/02_reduction.json")


if __name__ == "__main__":
    main()
