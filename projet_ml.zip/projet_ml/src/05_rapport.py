"""
Etape 5 : generation du rapport Word (rapport.docx) avec python-docx.

Regle du projet : chaque chiffre du rapport est lu dans results/metrics.csv
(aucune valeur n'est ecrite en dur dans ce script). Le nom du meilleur modele
et le type de reduction retenu sont lus dans les fichiers JSON de l'etape 3.

Structure du rapport (3 a 4 pages) :
  1. Contexte et objectif
  2. Donnees
  3. Methode (reduction, modeles, validation, seuil)
  4. Resultats (tableau + figures)
  5. Surapprentissage
  6. Interpretation du meilleur modele
  7. Limites et perspectives (extension aux signaux ECG)
  8. References du code (versions des librairies, sources)
"""

import json
import os
import sys

import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import RACINE, chemin_figure, chemin_result

CHEMIN_RAPPORT = os.path.join(RACINE, "rapport.docx")

# Identification obligatoire (consignes du professeur) : prenom, nom, groupe, sujet
PRENOM = "Dhafer"
NOM = "Smeti"
GROUPE = "INDIVIDUEL"            # ex. "Groupe 2" ; travail seul -> INDIVIDUEL
TRAVAIL = "Travail individuel"   # ou "Travail en groupe de 2" / "de 3"
SUJET = ("Sujet n° 3 : Aide au diagnostic médical via la modélisation de données "
         "tabulaires et de signaux")
# Librairies dont la version est citee dans la section "References du code"
LIBRAIRIES = ["numpy", "pandas", "scipy", "scikit-learn", "xgboost", "matplotlib", "seaborn",
              "shap", "joblib", "python-docx"]
MODELES = ["Regression logistique", "Random Forest", "Gradient Boosting", "XGBoost",
           "Reseau de neurones (MLP)"]
NOMS_AFFICHES = {"Regression logistique": "Régression logistique",
                 "Random Forest": "Random Forest",
                 "Gradient Boosting": "Gradient Boosting",
                 "XGBoost": "XGBoost",
                 "Reseau de neurones (MLP)": "Réseau de neurones (MLP)"}
# Noms avec article pour les phrases du rapport
NOMS_PROSE = {"Regression logistique": "la régression logistique",
              "Random Forest": "le Random Forest",
              "Gradient Boosting": "le Gradient Boosting",
              "XGBoost": "XGBoost",
              "Reseau de neurones (MLP)": "le réseau de neurones (MLP)"}


def liste_fr(elements):
    """Joint des elements en francais : 'a', 'a et b', 'a, b et c'."""
    elements = list(elements)
    return elements[0] if len(elements) == 1 else ", ".join(elements[:-1]) + " et " + elements[-1]


# ----------------------------------------------------------------------
# Acces aux chiffres : tout passe par metrics.csv
# ----------------------------------------------------------------------
class Metriques:
    """Petit accesseur sur results/metrics.csv (format long : modele, metrique, jeu, valeur)."""

    def __init__(self, chemin):
        self.df = pd.read_csv(chemin)

    def val(self, modele, metrique, jeu):
        sel = self.df[(self.df.modele == modele) & (self.df.metrique == metrique) &
                      (self.df.jeu == jeu)]
        if sel.empty:
            raise KeyError(f"Valeur absente de metrics.csv : {modele} / {metrique} / {jeu}")
        return float(sel["valeur"].iloc[0])

    def entier(self, modele, metrique, jeu="description"):
        return int(round(self.val(modele, metrique, jeu)))

    def importances(self, modele):
        """Variables les plus importantes (permutation), dans l'ordre, avec leur valeur."""
        sel = self.df[(self.df.modele == modele) & (self.df.jeu == "importance_permutation") &
                      (self.df.metrique.str.startswith("importance_"))].sort_values("metrique")
        return [(m.split("_", 2)[2], float(v)) for m, v in zip(sel.metrique, sel.valeur)]


def fr(x, decimales=3):
    """Formate un nombre a la francaise (virgule decimale)."""
    return f"{x:.{decimales}f}".replace(".", ",")


def fr_court(x):
    """Nombre a la francaise sans zeros inutiles (10,000 -> 10 ; 0,178 -> 0,178)."""
    return fr(x, 3).rstrip("0").rstrip(",")


def pct(x, decimales=1):
    """Formate une proportion (0 a 1) en pourcentage francais."""
    return f"{100 * x:.{decimales}f} %".replace(".", ",")


# ----------------------------------------------------------------------
# Aides de mise en page python-docx
# ----------------------------------------------------------------------
def configurer_document(doc):
    """Page A4, marges de 2 cm, police Calibri 10,5 pt, titres compacts."""
    for section in doc.sections:
        section.page_height, section.page_width = Cm(29.7), Cm(21.0)
        section.top_margin = section.bottom_margin = Cm(1.8)
        section.left_margin = section.right_margin = Cm(2.0)
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(10.5)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    normal.paragraph_format.space_after = Pt(4)
    normal.paragraph_format.line_spacing = 1.05
    for niveau, taille in [(1, 13), (2, 11.5)]:
        style = doc.styles[f"Heading {niveau}"]
        style.font.name = "Calibri"
        style.font.size = Pt(taille)
        style.font.bold = True
        style.font.color.rgb = RGBColor(0x1F, 0x3A, 0x5F)
        style.paragraph_format.space_before = Pt(8 if niveau == 1 else 5)
        style.paragraph_format.space_after = Pt(3)
        style.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")


def paragraphe(doc, texte, gras_debut=None, justifie=True):
    """Ajoute un paragraphe ; gras_debut est un texte en gras place en tete."""
    p = doc.add_paragraph()
    if gras_debut:
        p.add_run(gras_debut).bold = True
    p.add_run(texte)
    if justifie:
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    return p


def puce(doc, texte, gras_debut=None):
    p = doc.add_paragraph(style="List Bullet")
    if gras_debut:
        p.add_run(gras_debut).bold = True
    p.add_run(texte)
    p.paragraph_format.space_after = Pt(2)
    return p


def legende(doc, texte):
    p = doc.add_paragraph()
    r = p.add_run(texte)
    r.italic = True
    r.font.size = Pt(9)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(6)


def figures_cote_a_cote(doc, fichiers, largeur_cm, legende_texte):
    """Place 1 ou 2 images sur une ligne (tableau sans bordures) suivies d'une legende."""
    table = doc.add_table(rows=1, cols=len(fichiers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for cellule, fichier in zip(table.rows[0].cells, fichiers):
        cellule.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        cellule.paragraphs[0].add_run().add_picture(chemin_figure(fichier), width=Cm(largeur_cm))
    legende(doc, legende_texte)


def ombrer_cellule(cellule, couleur_hex):
    tcPr = cellule._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), couleur_hex)
    tcPr.append(shd)


def tableau(doc, entetes, lignes, taille_police=8, ligne_grasse=None):
    """Tableau avec en-tete colore ; ligne_grasse = index de la ligne a mettre en gras."""
    table = doc.add_table(rows=1, cols=len(entetes))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for cellule, texte in zip(table.rows[0].cells, entetes):
        cellule.text = ""
        run = cellule.paragraphs[0].add_run(texte)
        run.bold = True
        run.font.size = Pt(taille_police)
        cellule.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        ombrer_cellule(cellule, "D9E2F3")
    for i, ligne in enumerate(lignes):
        cellules = table.add_row().cells
        for j, (cellule, texte) in enumerate(zip(cellules, ligne)):
            cellule.text = ""
            run = cellule.paragraphs[0].add_run(str(texte))
            run.font.size = Pt(taille_police)
            run.bold = (i == ligne_grasse)
            cellule.paragraphs[0].alignment = (WD_ALIGN_PARAGRAPH.LEFT if j == 0
                                               else WD_ALIGN_PARAGRAPH.CENTER)
    return table


# ----------------------------------------------------------------------
# Redaction du rapport
# ----------------------------------------------------------------------
def main():
    m = Metriques(chemin_result("metrics.csv"))
    with open(chemin_result("03_meilleur_modele.json"), encoding="utf-8") as f:
        meilleur_info = json.load(f)
    with open(chemin_result("03_meilleurs_hyperparametres.json"), encoding="utf-8") as f:
        hyperparams = json.load(f)
    meilleur = meilleur_info["meilleur_modele"]
    meilleur_aff = NOMS_AFFICHES[meilleur]
    # Type de reduction retenu (texte du JSON) ; le nombre de dimensions vient de metrics.csv
    def libelle_reduction(nom):
        texte = hyperparams[nom]["hyperparametres"].get("reduction", "aucune")
        n_dims = m.entier(nom, "n_dimensions_apres_reduction", "hyperparametres")
        if texte.startswith("ACP"):
            return f"ACP ({n_dims} composantes)"
        if texte.startswith("selection"):
            return f"sélection L1 ({n_dims} variables)"
        return "aucune"

    reduction_retenue = {nom: libelle_reduction(nom) for nom in MODELES}

    # Raccourcis vers les chiffres les plus utilises
    n_patients = m.entier("donnees", "n_patients")
    n_variables = m.entier("donnees", "n_variables")
    n_benin, n_malin = m.entier("donnees", "n_benin"), m.entier("donnees", "n_malin")
    n_train, n_test = m.entier("donnees", "n_train"), m.entier("donnees", "n_test")
    n_malin_test = m.entier("donnees", "n_malin_test")
    n_comp = m.entier("acp", "n_composantes_acp_95")
    var_n_comp = m.val("acp", "variance_cumulee_n_comp_95", "description")
    var_2 = m.val("acp", "variance_cumulee_2_composantes", "description")
    n_lasso = m.entier("selection", "n_variables_lasso")
    n_corr = m.entier("selection", "n_variables_correlation")

    def cv(modele, metrique):
        return m.val(modele, metrique, "cv_moyenne"), m.val(modele, metrique, "cv_ecart_type")

    def test(modele, metrique, jeu="test_seuil_choisi"):
        return m.val(modele, metrique, jeu)

    doc = Document()
    configurer_document(doc)

    # ---- Titre -------------------------------------------------------
    titre = doc.add_paragraph()
    titre.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = titre.add_run("Aide au diagnostic médical par apprentissage automatique : "
                      "classification de tumeurs du sein à partir de descripteurs tabulaires")
    r.bold, r.font.size, r.font.color.rgb = True, Pt(15), RGBColor(0x1F, 0x3A, 0x5F)
    # Bloc d'identification bien visible (consigne : prenom, nom, groupe, sujet)
    ident = doc.add_table(rows=1, cols=1)
    ident.alignment = WD_TABLE_ALIGNMENT.CENTER
    ident.style = "Table Grid"
    cellule = ident.rows[0].cells[0]
    ombrer_cellule(cellule, "EEF3FA")
    p = cellule.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for etiquette, valeur in [("Prénom : ", PRENOM), ("Nom : ", NOM), ("Groupe : ", GROUPE)]:
        p.add_run(etiquette).font.size = Pt(10)
        r = p.add_run(valeur + "     ")
        r.bold, r.font.size = True, Pt(10)
    r = p.add_run(TRAVAIL)
    r.bold, r.font.size = True, Pt(10)
    p2 = cellule.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p2.add_run(SUJET)
    r.bold, r.font.size = True, Pt(10)
    for par in cellule.paragraphs:
        par.paragraph_format.space_after = Pt(1)
    espace = doc.add_paragraph()
    espace.paragraph_format.space_after = Pt(0)
    espace.add_run().font.size = Pt(4)

    # ---- 1. Contexte -------------------------------------------------
    doc.add_heading("1. Contexte et objectif", level=1)
    paragraphe(doc,
        "Le dépistage du cancer du sein repose en partie sur l'examen de cellules prélevées "
        "par cytoponction. L'objectif de ce projet est de construire un outil d'aide au "
        "diagnostic qui prédit si une tumeur est maligne ou bénigne à partir de mesures "
        "numériques décrivant les noyaux cellulaires. Dans ce contexte, l'erreur la plus grave "
        "est le faux négatif (cancer non détecté) : le rappel sur la classe maligne est donc la "
        "métrique prioritaire, sans négliger la précision pour limiter les examens inutiles. "
        "Conformément au sujet, nous comparons un réseau de neurones profond (MLP) à des "
        "classificateurs d'ensemble optimisés (Random Forest, Gradient Boosting, XGBoost) et à "
        "une régression logistique de référence, après une étape de réduction de dimension "
        "destinée à limiter le surapprentissage. Tout le code est en Python (scikit-learn, "
        "XGBoost, SHAP) et s'exécute avec un seul script, main.py, avec des graines aléatoires fixées.")

    # ---- 2. Donnees --------------------------------------------------
    doc.add_heading("2. Données", level=1)
    paragraphe(doc,
        f"Le jeu de données Breast Cancer Wisconsin (Diagnostic), fourni par scikit-learn, "
        f"contient {n_patients} patientes décrites par {n_variables} variables numériques, sans "
        f"aucune valeur manquante. La classe "
        f"positive est la tumeur maligne : {n_malin} cas ({pct(m.val('donnees', 'pct_malin', 'description') / 100)}) "
        f"contre {n_benin} tumeurs bénignes. Le déséquilibre est modéré mais réel, ce qui justifie "
        f"des métriques adaptées (PR-AUC, balanced accuracy, MCC) plutôt que la seule exactitude.")
    paragraphe(doc,
        "Les 30 variables ne sont pas des mesures cliniques brutes mais des descripteurs extraits "
        "d'images : sur chaque image numérisée de cytoponction, les contours des noyaux sont "
        "segmentés et dix caractéristiques géométriques ou de texture sont calculées (rayon, "
        "texture, périmètre, aire, lissage, compacité, concavité, points concaves, symétrie, "
        "dimension fractale). Pour chacune, la moyenne, l'erreur standard et la plus grande valeur "
        "(worst) sur les noyaux de l'image donnent les 30 variables. Cette origine explique la "
        f"forte redondance observée : {m.entier('donnees', 'n_paires_corr_sup_0_9')} paires de "
        "variables ont une corrélation supérieure à 0,9 (rayon, périmètre et aire par exemple), ce "
        "qui motive la réduction de dimension. Les variables les plus liées à la malignité sont "
        "les mesures de concavité et de taille des noyaux (worst concave points, worst perimeter, "
        "mean concave points).")
    paragraphe(doc,
        f"Un jeu de test de {n_test} patientes ({n_malin_test} malignes) a été mis de côté dès le "
        f"départ par tirage stratifié. Seule l'exploration descriptive (effectifs, corrélations) "
        f"porte sur l'ensemble des données ; tout ce qui influence les modèles (ACP, sélection de "
        f"variables, optimisation, choix du seuil) utilise uniquement les {n_train} patientes "
        f"d'entraînement.")

    # ---- 3. Methode --------------------------------------------------
    doc.add_heading("3. Méthode", level=1)
    doc.add_heading("3.1 Réduction de dimension et sélection de variables", level=2)
    sel_toutes = m.val("selection : Toutes (30)", "average_precision", "cv_moyenne")
    sel_acp = m.val(f"selection : ACP ({n_comp} comp.)", "average_precision", "cv_moyenne")
    sel_lasso = m.val(f"selection : LASSO ({n_lasso})", "average_precision", "cv_moyenne")
    sel_foret = m.val("selection : Forêt (10)", "average_precision", "cv_moyenne")
    c_1se = m.val("selection", "lasso_C_1se", "description")
    c_meilleur = m.val("selection", "lasso_C_meilleur", "description")
    calibration_sigmoide = m.val("calibration", "sigmoide", "description") > 0
    paragraphe(doc,
        f"Après standardisation, une analyse en composantes principales (ACP) montre que deux "
        f"composantes résument {pct(var_2)} de la variance et que {n_comp} composantes suffisent "
        f"pour en expliquer {pct(var_n_comp)} (seuil retenu de 95 %, figure 1). Trois méthodes de "
        f"sélection de variables ont été comparées : un filtre de redondance qui retire une variable "
        f"de chaque paire corrélée à plus de 0,9 ({n_corr} variables conservées), une régression "
        f"logistique pénalisée L1 (LASSO) et l'importance d'une forêt aléatoire (10 variables "
        f"retenues). Pour le LASSO, la force de pénalité est choisie sur une grille logarithmique de "
        f"0,001 à 100 par la règle « un écart-type » : on retient la pénalité la plus forte dont le "
        f"score reste à moins d'une erreur standard du meilleur, soit C = {fr_court(c_1se)} au lieu de "
        f"C = {fr_court(c_meilleur)}, ce qui ne garde que {n_lasso} variables à coefficient non nul. "
        f"Chaque stratégie est évaluée avec une régression logistique en validation croisée à 5 plis, "
        f"la sélection LASSO ou forêt et l'ACP étant refaites dans chaque pli (SelectFromModel dans "
        f"un Pipeline) pour éviter un biais de sélection optimiste. La PR-AUC moyenne vaut "
        f"{fr(sel_toutes)} avec les 30 variables, {fr(sel_acp)} avec l'ACP à {n_comp} composantes, "
        f"{fr(sel_lasso)} avec le LASSO et {fr(sel_foret)} avec les 10 variables de la forêt : on "
        f"peut réduire fortement la dimension en perdant peu d'information, mais toute sélection "
        f"agressive se paie en rappel.")
    doc.add_heading("3.2 Modèles, validation croisée et choix du seuil", level=2)
    paragraphe(doc,
        "Chaque modèle est encapsulé dans un Pipeline scikit-learn : standardisation, puis une "
        "étape de réduction (aucune, ACP à " + str(n_comp) + " composantes, ou sélection L1), puis le "
        "classifieur. Le choix de la réduction fait partie des hyperparamètres optimisés ; comme "
        "chaque étape est réajustée dans chaque pli, aucune information du jeu de validation ou du "
        "jeu de test ne fuit vers l'entraînement. Cinq modèles sont comparés : la régression "
        "logistique (baseline), Random Forest, Gradient Boosting, XGBoost et un MLP à deux ou trois "
        "couches cachées avec arrêt précoce (15 % du train servent de validation interne et "
        "l'entraînement s'arrête quand la perte ne baisse plus pendant 20 itérations). Les "
        "hyperparamètres sont optimisés par GridSearchCV (régression logistique) ou RandomizedSearchCV "
        "(25 candidats pour les autres) en validation croisée stratifiée à 5 plis sur le jeu "
        "d'entraînement, avec la PR-AUC comme critère de sélection.")
    paragraphe(doc,
        "Les métriques suivies sont le rappel, la précision, le F1, la ROC-AUC, la PR-AUC, la "
        "balanced accuracy et le coefficient de corrélation de Matthews (MCC), rapportées en moyenne "
        "et écart-type sur les 5 plis, puis mesurées une seule fois sur le jeu de test. Comme les "
        "ensembles d'arbres et le MLP produisent des probabilités mal calibrées, chaque meilleur "
        "pipeline est enveloppé dans un CalibratedClassifierCV ("
        + ("sigmoïde de Platt, le train comptant moins de 1000 exemples" if calibration_sigmoide
           else "régression isotonique")
        + ", 5 plis internes) ; c'est ce modèle calibré qui est évalué en validation croisée, qui "
        "sert au choix du seuil et qui est appliqué au test. Le seuil de décision n'est pas laissé "
        "à 0,5 : pour chaque modèle, on calcule des probabilités calibrées hors pli sur le train et "
        "on retient le seuil qui maximise le F2-score, qui pondère le rappel deux fois plus que la "
        "précision, en cohérence avec le coût élevé d'un faux négatif. Cette règle unique rend les "
        "seuils comparables d'un modèle à l'autre.")
    figures_cote_a_cote(doc, ["02_acp_variance_expliquee.png", "02_acp_projection_2d.png"], 7.6,
        f"Figure 1. ACP sur le jeu d'entraînement : variance expliquée et choix de {n_comp} "
        f"composantes (gauche) ; projection des patientes sur les deux premières composantes (droite).")

    # ---- 4. Resultats ------------------------------------------------
    doc.add_heading("4. Résultats", level=1)
    entetes = ["Modèle", "Réduction retenue", "Rappel CV", "Précision CV", "F1 CV", "ROC-AUC CV",
               "PR-AUC CV", "MCC CV", "Seuil", "Rappel test", "Précision test", "FN test (0,5 / seuil)"]
    lignes = []
    for nom in MODELES:
        rap, prec, f1 = cv(nom, "rappel"), cv(nom, "precision"), cv(nom, "f1")
        roc, pr, mcc = cv(nom, "roc_auc"), cv(nom, "pr_auc"), cv(nom, "mcc")
        seuil = m.val(nom, "seuil_choisi", "cv")
        lignes.append([
            NOMS_AFFICHES[nom], reduction_retenue[nom],
            f"{fr(rap[0])} ± {fr(rap[1])}", f"{fr(prec[0])} ± {fr(prec[1])}",
            f"{fr(f1[0])} ± {fr(f1[1])}", f"{fr(roc[0])} ± {fr(roc[1])}",
            f"{fr(pr[0])} ± {fr(pr[1])}", f"{fr(mcc[0])} ± {fr(mcc[1])}", fr(seuil, 2),
            fr(test(nom, "rappel")), fr(test(nom, "precision")),
            f"{int(test(nom, 'faux_negatifs', 'test_seuil_0.5'))} / {int(test(nom, 'faux_negatifs'))}",
        ])
    tableau(doc, entetes, lignes, taille_police=7.5, ligne_grasse=MODELES.index(meilleur))
    legende(doc, "Tableau 1. Scores en validation croisée (moyenne ± écart-type sur 5 plis, "
                 "seuil 0,5) et sur le jeu de test au seuil optimisé (F2). FN = faux négatifs sur "
                 f"les {n_malin_test} tumeurs malignes du test. En gras : meilleur modèle selon la PR-AUC en CV.")

    # Texte de synthese des resultats, construit a partir des chiffres
    pr_meilleur = cv(meilleur, "pr_auc")
    classement = meilleur_info["classement"]
    second = classement[1]
    pr_second = cv(second, "pr_auc")
    rappels_cv = {nom: cv(nom, "rappel")[0] for nom in MODELES}
    rappel_max = max(rappels_cv.values())
    # Plusieurs modeles peuvent etre a egalite (a l'arrondi pres) : on les cite tous
    modeles_rappel_max = [nom for nom in MODELES if fr(rappels_cv[nom]) == fr(rappel_max)]
    fn_05 = {nom: int(test(nom, "faux_negatifs", "test_seuil_0.5")) for nom in MODELES}
    fn_seuil = {nom: int(test(nom, "faux_negatifs")) for nom in MODELES}
    paragraphe(doc,
        f"Tous les modèles optimisés atteignent des performances élevées et proches, avec des "
        f"ROC-AUC et PR-AUC en validation croisée au moins égales à "
        f"{fr(min(cv(n, 'pr_auc')[0] for n in MODELES))}. Le meilleur modèle selon la PR-AUC "
        f"moyenne en validation croisée est {NOMS_PROSE[meilleur]} ({fr(pr_meilleur[0])} ± {fr(pr_meilleur[1])}), "
        f"devant {NOMS_PROSE[second]} ({fr(pr_second[0])} ± {fr(pr_second[1])}). Les écarts entre "
        f"modèles sont toutefois inférieurs aux écarts-types entre plis : sur ce jeu de petite "
        f"taille et presque linéairement séparable, aucun modèle ne domine significativement, et le "
        f"réseau de neurones n'apporte pas de gain sur les ensembles ni sur la baseline linéaire. "
        f"Le rappel moyen en CV le plus élevé ({fr(rappel_max)}) est obtenu par "
        f"{liste_fr(NOMS_PROSE[n] for n in modeles_rappel_max)}.")
    paragraphe(doc,
        f"Sur le jeu de test, {NOMS_PROSE[meilleur]} obtient une ROC-AUC de "
        f"{fr(test(meilleur, 'roc_auc'))} et une PR-AUC de {fr(test(meilleur, 'pr_auc'))}. Au seuil "
        f"par défaut de 0,5 il manque {fn_05[meilleur]} tumeurs malignes (rappel "
        f"{fr(test(meilleur, 'rappel', 'test_seuil_0.5'))}) ; avec le seuil optimisé de "
        f"{fr(m.val(meilleur, 'seuil_choisi', 'cv'), 2)}, le nombre de faux négatifs tombe à "
        f"{fn_seuil[meilleur]} (rappel {fr(test(meilleur, 'rappel'))}) pour une précision de "
        f"{fr(test(meilleur, 'precision'))} et un MCC de {fr(test(meilleur, 'mcc'))}. Le même effet "
        f"se voit en validation croisée : au seuil 0,5 le modèle calibré est prudent (rappel "
        f"{fr(cv(meilleur, 'rappel')[0])} pour une précision de {fr(cv(meilleur, 'precision')[0])}), "
        f"et seul le seuil optimisé rétablit le compromis voulu. Le choix du "
        f"seuil est donc le levier le plus efficace pour le rappel : il réduit les faux négatifs "
        f"pour {sum(fn_seuil[n] < fn_05[n] for n in MODELES)} modèles sur {len(MODELES)}, au prix de "
        f"quelques faux positifs supplémentaires, ce qui est le compromis souhaité en dépistage.")
    figures_cote_a_cote(doc, ["03_courbes_roc.png", "03_courbes_pr.png"], 7.6,
        "Figure 2. Courbes ROC (gauche) et précision-rappel (droite) des cinq modèles sur le jeu de test.")

    # ---- 5. Surapprentissage -----------------------------------------
    doc.add_heading("5. Surapprentissage", level=1)
    ecarts = {nom: m.val(nom, "pr_auc", "train_moyenne") - cv(nom, "pr_auc")[0] for nom in MODELES}
    train_pr = {nom: m.val(nom, "pr_auc", "train_moyenne") for nom in MODELES}
    ensembles = ["Random Forest", "Gradient Boosting", "XGBoost"]
    if len({fr(train_pr[n]) for n in ensembles}) == 1:
        texte_train = (f"atteignent tous les trois une PR-AUC d'entraînement de "
                       f"{fr(train_pr[ensembles[0]])}, c'est-à-dire qu'ils mémorisent parfaitement "
                       f"le train,")
    else:
        texte_train = (f"atteignent une PR-AUC d'entraînement de "
                       f"{', '.join(fr(train_pr[n]) for n in ensembles)} (Random Forest, Gradient "
                       f"Boosting, XGBoost), c'est-à-dire qu'ils mémorisent presque parfaitement le train,")
    paragraphe(doc,
        f"L'écart entre le score d'entraînement et le score de validation mesure le surapprentissage. "
        f"Les trois ensembles d'arbres (Random Forest, Gradient Boosting, XGBoost) {texte_train} "
        f"pour une PR-AUC en validation de "
        f"{', '.join(fr(cv(n, 'pr_auc')[0]) for n in ensembles)} respectivement : l'écart reste faible "
        f"(au plus {fr(max(ecarts[n] for n in ensembles))}) grâce à la validation croisée qui a "
        f"sélectionné des arbres peu profonds, du sous-échantillonnage ou une réduction de dimension. "
        f"La régression logistique et le MLP, régularisés (pénalité L2 et arrêt précoce), présentent "
        f"les écarts les plus petits ({fr(ecarts['Regression logistique'])} et "
        f"{fr(ecarts['Reseau de neurones (MLP)'])}). Enfin, les scores de test sont cohérents avec "
        f"les scores de validation croisée (ROC-AUC test de {fr(test(meilleur, 'roc_auc'))} contre "
        f"{fr(cv(meilleur, 'roc_auc')[0])} en CV pour {NOMS_PROSE[meilleur]}), ce qui confirme l'absence de "
        f"fuite de données et une bonne généralisation. Le seuil ayant été choisi sur des "
        f"probabilités hors pli et non sur le test, il n'est pas non plus surajusté au test.")

    # ---- 6. Interpretation -------------------------------------------
    doc.add_heading("6. Interprétation du meilleur modèle", level=1)
    imps = m.importances(meilleur)
    top5 = ", ".join(f"{v} ({fr(i)})" for v, i in imps[:5])
    shap_ok = m.val(meilleur, "shap_disponible", "importance_permutation") > 0
    paragraphe(doc,
        f"L'importance par permutation (baisse de PR-AUC sur le test quand une variable est "
        f"mélangée, 30 répétitions) désigne comme variables les plus utiles à {NOMS_PROSE[meilleur]} : "
        f"{top5}. Ces descripteurs, pris sur les noyaux les plus anormaux de l'image (stade worst) "
        f"ou en moyenne, traduisent l'irrégularité des noyaux (texture, symétrie, concavité, points "
        f"concaves) et leur taille, ce qui correspond aux critères cytologiques connus des tumeurs "
        f"malignes : noyaux plus gros, plus hétérogènes et aux contours plus irréguliers. "
        + ("Les valeurs de SHAP (figure 04_shap_resume.png dans figures/) confirment le sens de ces "
           "effets : des valeurs élevées de ces variables poussent la prédiction vers la classe maligne. "
           if shap_ok else "")
        + "Les importances individuelles restent modestes car de nombreuses variables sont redondantes : "
          "le modèle peut compenser la perte d'une variable par une variable corrélée.")
    figures_cote_a_cote(doc, ["04_importance_permutation.png", "03_choix_seuil.png"], 7.6,
        f"Figure 3. Importance par permutation sur le test (gauche) et choix du seuil de décision "
        f"maximisant le F2 sur les probabilités hors pli (droite) pour le modèle {meilleur_aff}.")

    # ---- 7. Limites et perspectives ----------------------------------
    doc.add_heading("7. Limites et perspectives", level=1)
    puce(doc, f" {n_patients} patientes et {n_malin_test} cas malins seulement dans le test : un faux "
              "négatif de plus ou de moins change le rappel de plusieurs points, d'où des intervalles "
              "larges et des différences entre modèles non significatives. Une validation croisée "
              "imbriquée ou un bootstrap donneraient des intervalles de confiance plus fiables.",
         "Taille de l'échantillon.")
    puce(doc, " Les données proviennent d'un seul centre et d'une seule technique d'imagerie ; la "
              "performance sur d'autres hôpitaux ou appareils n'est pas garantie et devrait être "
              "vérifiée par une validation externe.", "Représentativité.")
    puce(doc, " Le seuil optimisé repose sur un choix de pondération (F2) ; en pratique il devrait être "
              "fixé avec des cliniciens à partir des coûts réels des deux types d'erreur et de la "
              "prévalence locale. Un outil de ce type reste une aide à la décision et non un diagnostic.",
         "Seuil et usage clinique.")
    puce(doc, " Les hyperparamètres et le seuil ont été choisis sur les mêmes 5 plis du jeu "
              "d'entraînement, ce qui rend les scores de validation croisée légèrement optimistes ; "
              "une validation croisée imbriquée (boucle externe pour l'évaluation, boucle interne "
              "pour l'optimisation) est la perspective naturelle pour y remédier.",
         "Protocole.")
    paragraphe(doc,
        "Le sujet associe données tabulaires et signaux. Les 30 variables "
        "utilisées ici sont déjà le résultat d'une extraction de caractéristiques à partir d'images, "
        "et la même démarche s'applique à un signal physiologique comme l'électrocardiogramme (ECG). "
        "Une première approche consiste à transformer chaque enregistrement ECG en un vecteur de "
        "descripteurs (fréquence cardiaque, intervalles RR et QT, amplitude des ondes, coefficients "
        "d'ondelettes, variabilité) puis à réutiliser exactement le pipeline de ce projet : "
        "standardisation, réduction de dimension, ensembles et MLP, métriques adaptées au déséquilibre "
        "et seuil orienté rappel, les arythmies étant rares. Une seconde approche, plus proche de "
        "l'apprentissage profond, remplace l'extraction manuelle par un réseau convolutif 1D appliqué "
        "au signal brut, avec arrêt précoce et augmentation de données ; la base MIT-BIH Arrhythmia "
        "de PhysioNet constitue le jeu de référence pour comparer les deux approches avec le même "
        "protocole de validation croisée stratifiée.", gras_debut="Extension aux signaux ECG. ")

    # ---- 8. References du code --------------------------------------
    # Les versions sont lues dans l'environnement qui a produit les resultats
    # (pas ecrites en dur), pour que le rapport decrive exactement ce qui a tourne.
    import importlib.metadata as meta
    import platform
    versions = ", ".join(f"{lib} {meta.version(lib)}" for lib in LIBRAIRIES)
    doc.add_heading("8. Références du code", level=1)
    paragraphe(doc,
        f" Python {platform.python_version()} avec {versions} (versions exactes de l'exécution, "
        "minima dans requirements.txt). Cinq scripts src/01 à 05 (exploration, réduction, modèles, "
        "interprétation, rapport) sont enchaînés par main.py avec des graines fixées ; chaque "
        "chiffre de ce document est lu dans results/metrics.csv.",
        gras_debut="Environnement et organisation.")
    paragraphe(doc,
        " Jeu de données Breast Cancer Wisconsin (Diagnostic), UCI Machine Learning Repository "
        "(Wolberg, Mangasarian, Street et Street, 1995) et article d'origine des 30 descripteurs "
        "(Street, Wolberg et Mangasarian, 1993) ; documentation scikit-learn (Pipeline, PCA, "
        "SelectFromModel, GridSearchCV, StratifiedKFold, CalibratedClassifierCV, métriques, "
        "permutation_importance) ; XGBoost (Chen et Guestrin, 2016) ; SHAP (Lundberg et Lee, 2017) ; "
        "calibration sigmoïde (Platt, 1999). Le code a été écrit pour ce projet à partir des "
        "exemples de ces documentations, sans bloc copié d'un dépôt tiers ; liste complète avec "
        "liens dans references.md.", gras_debut="Sources utilisées.")

    doc.save(CHEMIN_RAPPORT)
    print(f"Rapport genere : {CHEMIN_RAPPORT}")


if __name__ == "__main__":
    main()
