"""
Etape 3 : modelisation supervisee et evaluation.

Modeles compares :
  - Regression logistique (baseline lineaire),
  - Random Forest (ensemble par bagging),
  - Gradient Boosting (scikit-learn) et XGBoost (ensembles par boosting),
  - Reseau de neurones profond MLP (2 a 3 couches cachees, arret precoce).

Chaque modele est place dans un Pipeline scikit-learn :
    StandardScaler -> reduction (aucune / ACP / selection L1) -> modele
Le Pipeline garantit que la standardisation et la reduction sont reajustees
dans chaque pli de validation croisee, donc sans fuite de donnees.

Les hyperparametres (y compris le choix de la reduction) sont optimises par
GridSearchCV / RandomizedSearchCV en validation croisee stratifiee a 5 plis
sur le jeu d'entrainement (80 %). Le critere d'optimisation est la PR-AUC
(average precision), bien adaptee au desequilibre. Le jeu de test (20 %) est
evalue une seule fois a la fin.

Calibration : les probabilites brutes des ensembles d'arbres ou du MLP sont
souvent mal calibrees (trop proches de 0 ou 1). Chaque meilleur pipeline est
donc enveloppe dans un CalibratedClassifierCV (methode sigmoide de Platt quand
le train compte moins de 1000 exemples, isotonique sinon) : c'est ce modele
calibre qui est evalue en validation croisee, qui sert au choix du seuil et
qui est applique au test. La calibration est monotone, donc elle ne change
pas la ROC-AUC ni la PR-AUC, mais elle rend le seuil comparable d'un modele a
l'autre.

Choix du seuil : par defaut un classifieur predit "malin" si la probabilite
depasse 0.5. En diagnostic medical, un faux negatif (cancer manque) coute plus
cher qu'un faux positif. On choisit donc le seuil qui maximise le F2-score
(rappel pondere 2 fois plus que la precision) sur les probabilites calibrees
"hors pli" obtenues par validation croisee sur le train, puis on l'applique au test.

Sorties :
  results/metrics.csv                     (toutes les metriques, format long)
  results/03_resume_test.csv              (tableau lisible des scores test)
  results/03_meilleurs_hyperparametres.json
  results/03_meilleur_modele.json
  results/modeles/*.joblib                (pipelines entraines)
  figures/03_courbes_roc.png, 03_courbes_pr.png, 03_matrices_confusion.png,
  figures/03_comparaison_cv.png, 03_surapprentissage.png, 03_choix_seuil.png
"""

import json
import os
import sys
import time
import warnings

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy.stats import loguniform
from sklearn.base import clone
from sklearn.calibration import CalibratedClassifierCV
from sklearn.decomposition import PCA
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (ConfusionMatrixDisplay, average_precision_score,
                             balanced_accuracy_score, confusion_matrix, f1_score,
                             matthews_corrcoef, precision_recall_curve,
                             precision_score, recall_score, roc_auc_score,
                             roc_curve)
from sklearn.model_selection import (GridSearchCV, RandomizedSearchCV,
                                     StratifiedKFold, cross_val_predict,
                                     cross_validate)
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (DOSSIER_MODELES, NOM_CLASSES, RANDOM_STATE, charger_donnees, nom_affiche,
                    chemin_figure, chemin_result, creer_dossiers, fixer_graines,
                    separer_train_test)

warnings.filterwarnings("ignore", category=ConvergenceWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

# Metriques suivies en validation croisee (noms scikit-learn -> noms affiches)
SCORING = {
    "rappel": "recall",
    "precision": "precision",
    "f1": "f1",
    "roc_auc": "roc_auc",
    "pr_auc": "average_precision",
    "balanced_accuracy": "balanced_accuracy",
    "mcc": "matthews_corrcoef",
}
METRIQUE_OPTIMISATION = "pr_auc"  # critere de refit des recherches d'hyperparametres
BETA_SEUIL = 2.0                  # F-beta pour le choix du seuil (beta > 1 favorise le rappel)


# ----------------------------------------------------------------------
# Definition des modeles et de leurs espaces d'hyperparametres
# ----------------------------------------------------------------------
def options_reduction(n_comp_acp):
    """Les trois options de l'etape 'reduction' du Pipeline, testees par la recherche."""
    return [
        "passthrough",                                           # aucune reduction
        PCA(n_components=n_comp_acp, random_state=RANDOM_STATE),  # ACP
        # selection L1 : l1_ratio=1.0 = penalite L1 pure (scikit-learn >= 1.8)
        SelectFromModel(LogisticRegression(l1_ratio=1.0, C=0.5, solver="liblinear",
                                           random_state=RANDOM_STATE)),
    ]


def construire_recherches(n_comp_acp, cv, ratio_classes):
    """
    Renvoie un dictionnaire {nom_modele: objet de recherche d'hyperparametres}.
    Chaque recherche porte sur un Pipeline complet (scaler + reduction + modele).
    """
    reductions = options_reduction(n_comp_acp)

    def pipeline(modele):
        return Pipeline([("scaler", StandardScaler()),
                         ("reduction", "passthrough"),
                         ("modele", modele)])

    communs = dict(cv=cv, scoring=SCORING, refit=METRIQUE_OPTIMISATION,
                   return_train_score=True, n_jobs=-1)

    recherches = {}

    # 1. Baseline : regression logistique (grille complete, petit espace)
    recherches["Regression logistique"] = GridSearchCV(
        pipeline(LogisticRegression(max_iter=5000, random_state=RANDOM_STATE)),
        param_grid={
            "reduction": reductions,
            "modele__C": [0.01, 0.1, 1, 10, 100],
            "modele__class_weight": [None, "balanced"],
        }, **communs)

    # 2. Random Forest (recherche aleatoire)
    recherches["Random Forest"] = RandomizedSearchCV(
        pipeline(RandomForestClassifier(random_state=RANDOM_STATE, n_jobs=1)),
        param_distributions={
            "reduction": reductions,
            "modele__n_estimators": [200, 300, 500],
            "modele__max_depth": [None, 4, 6, 8, 12],
            "modele__min_samples_leaf": [1, 2, 4],
            "modele__max_features": ["sqrt", "log2", 0.5],
            "modele__class_weight": [None, "balanced"],
        }, n_iter=25, random_state=RANDOM_STATE, **communs)

    # 3. Gradient Boosting scikit-learn
    recherches["Gradient Boosting"] = RandomizedSearchCV(
        pipeline(GradientBoostingClassifier(random_state=RANDOM_STATE)),
        param_distributions={
            "reduction": reductions,
            "modele__n_estimators": [100, 200, 400],
            "modele__learning_rate": [0.01, 0.05, 0.1, 0.2],
            "modele__max_depth": [2, 3, 4],
            "modele__subsample": [0.7, 0.85, 1.0],
            "modele__min_samples_leaf": [1, 3, 5],
        }, n_iter=25, random_state=RANDOM_STATE, **communs)

    # 4. XGBoost
    recherches["XGBoost"] = RandomizedSearchCV(
        pipeline(XGBClassifier(random_state=RANDOM_STATE, n_jobs=1,
                               eval_metric="logloss", verbosity=0)),
        param_distributions={
            "reduction": reductions,
            "modele__n_estimators": [100, 200, 400],
            "modele__learning_rate": [0.01, 0.05, 0.1, 0.2],
            "modele__max_depth": [2, 3, 4, 6],
            "modele__subsample": [0.7, 0.85, 1.0],
            "modele__colsample_bytree": [0.6, 0.8, 1.0],
            "modele__reg_lambda": [0.5, 1, 2, 5],
            # Ponderation de la classe positive = n_negatifs / n_positifs (ou aucune)
            "modele__scale_pos_weight": [1.0, ratio_classes],
        }, n_iter=25, random_state=RANDOM_STATE, **communs)

    # 5. Reseau de neurones profond (MLP, 2 a 3 couches cachees, arret precoce)
    recherches["Reseau de neurones (MLP)"] = RandomizedSearchCV(
        pipeline(MLPClassifier(early_stopping=True, validation_fraction=0.15,
                               n_iter_no_change=20, max_iter=1000,
                               random_state=RANDOM_STATE)),
        param_distributions={
            "reduction": reductions,
            "modele__hidden_layer_sizes": [(32, 16), (64, 32), (128, 64),
                                           (64, 64, 32), (128, 64, 32), (64, 32, 16)],
            "modele__activation": ["relu", "tanh"],
            "modele__alpha": loguniform(1e-5, 1e-1),          # regularisation L2
            "modele__learning_rate_init": [1e-3, 3e-3, 1e-2],
            "modele__batch_size": [32, 64],
        }, n_iter=25, random_state=RANDOM_STATE, **communs)

    return recherches


# ----------------------------------------------------------------------
# Fonctions utilitaires d'evaluation
# ----------------------------------------------------------------------
def calculer_metriques(y_vrai, proba, seuil):
    """Toutes les metriques de classification pour un seuil de decision donne."""
    pred = (proba >= seuil).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_vrai, pred, labels=[0, 1]).ravel()
    return {
        "rappel": recall_score(y_vrai, pred, zero_division=0),
        "precision": precision_score(y_vrai, pred, zero_division=0),
        "f1": f1_score(y_vrai, pred, zero_division=0),
        "roc_auc": roc_auc_score(y_vrai, proba),
        "pr_auc": average_precision_score(y_vrai, proba),
        "balanced_accuracy": balanced_accuracy_score(y_vrai, pred),
        "mcc": matthews_corrcoef(y_vrai, pred),
        "specificite": tn / (tn + fp) if (tn + fp) > 0 else 0.0,
        "vrais_negatifs": int(tn), "faux_positifs": int(fp),
        "faux_negatifs": int(fn), "vrais_positifs": int(tp),
    }


def choisir_seuil(y_vrai, proba, beta=BETA_SEUIL):
    """
    Seuil qui maximise le F-beta score (beta = 2 : le rappel compte 2 fois plus
    que la precision). Calcule sur des probabilites hors pli (jamais sur le test).
    """
    precision, rappel, seuils = precision_recall_curve(y_vrai, proba)
    # precision_recall_curve renvoie un point de plus que de seuils : on l'ignore
    precision, rappel = precision[:-1], rappel[:-1]
    fbeta = (1 + beta ** 2) * precision * rappel / np.maximum(beta ** 2 * precision + rappel, 1e-12)
    idx = int(np.argmax(fbeta))
    return float(seuils[idx]), float(fbeta[idx])


def nom_fichier(nom):
    """Transforme un nom de modele en nom de fichier simple."""
    return (nom.lower().replace(" ", "_").replace("(", "").replace(")", "")
            .replace("é", "e").replace("è", "e"))


def decrire_reduction(etape):
    """Nom lisible de l'option de reduction retenue dans un pipeline."""
    if isinstance(etape, str):
        return "aucune"
    if isinstance(etape, PCA):
        return f"ACP ({etape.n_components} composantes)"
    if isinstance(etape, SelectFromModel):
        return f"selection L1 ({int(etape.get_support().sum())} variables)"
    return type(etape).__name__


# ----------------------------------------------------------------------
# Programme principal
# ----------------------------------------------------------------------
def main():
    fixer_graines()
    creer_dossiers()
    sns.set_theme(style="whitegrid")

    print("=" * 70)
    print("ETAPE 3 : MODELISATION (MLP vs ensembles vs regression logistique)")
    print("=" * 70)

    # Donnees et separation train / test (le test est mis de cote)
    X, y, noms = charger_donnees()
    X_train, X_test, y_train, y_test = separer_train_test(X, y)
    print(f"Train : {len(X_train)} patients ({int(y_train.sum())} malins) | "
          f"Test : {len(X_test)} patients ({int(y_test.sum())} malins)")
    ratio_classes = float((y_train == 0).sum() / (y_train == 1).sum())

    # Nombre de composantes ACP choisi a l'etape 2 (95 % de variance)
    with open(chemin_result("02_reduction.json"), encoding="utf-8") as f:
        reduction_info = json.load(f)
    n_comp_acp = reduction_info["n_composantes_acp_95"]
    with open(chemin_result("01_description_donnees.json"), encoding="utf-8") as f:
        description = json.load(f)

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    recherches = construire_recherches(n_comp_acp, cv, ratio_classes)

    # Calibration des probabilites : la methode isotonique demande beaucoup
    # d'exemples (environ 1000 ou plus) ; en dessous, la sigmoide de Platt est plus sure.
    methode_calibration = "isotonic" if len(X_train) >= 1000 else "sigmoid"
    cv_calibration = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    print(f"Calibration des probabilites : methode '{methode_calibration}' "
          f"({len(X_train)} exemples d'entrainement), 5 plis internes")

    lignes_metrics = []        # format long pour results/metrics.csv
    resume_test = []           # tableau lisible
    meilleurs_params = {}
    modeles_entraines = {}
    probas_test = {}
    seuils = {}

    # ---- Recherche d'hyperparametres, modele par modele ---------------
    for nom, recherche in recherches.items():
        debut = time.time()
        print(f"\n--- {nom} ---")
        recherche.fit(X_train, y_train)
        duree = time.time() - debut
        meilleur = recherche.best_estimator_
        idx = recherche.best_index_
        res = recherche.cv_results_

        # Hyperparametres retenus (convertis en texte pour le JSON)
        # Pour l'etape "reduction", on decrit l'objet AJUSTE du meilleur pipeline
        # (best_params_ ne contient que l'objet non ajuste)
        params = {k: (decrire_reduction(meilleur.named_steps["reduction"]) if k == "reduction"
                      else (v if isinstance(v, (int, float, str, type(None))) else str(v)))
                  for k, v in recherche.best_params_.items()}
        meilleurs_params[nom] = {"hyperparametres": params,
                                 "duree_recherche_s": round(duree, 1),
                                 "n_candidats_testes": len(res["params"])}
        print(f"  Meilleurs hyperparametres : {params}")
        print(f"  Recherche : {len(res['params'])} candidats x 5 plis en {duree:.0f} s")

        # Nombre de dimensions en sortie de l'etape de reduction retenue
        etape_reduction = meilleur.named_steps["reduction"]
        if isinstance(etape_reduction, PCA):
            n_dims = int(etape_reduction.n_components_)
        elif isinstance(etape_reduction, SelectFromModel):
            n_dims = int(etape_reduction.get_support().sum())
        else:
            n_dims = X_train.shape[1]
        lignes_metrics.append({"modele": nom, "metrique": "n_dimensions_apres_reduction",
                               "jeu": "hyperparametres", "valeur": float(n_dims)})

        # Hyperparametres numeriques ajoutes a metrics.csv (source unique du rapport)
        for cle, valeur in recherche.best_params_.items():
            nom_param = cle.replace("modele__", "")
            if isinstance(valeur, bool) or valeur is None or isinstance(valeur, str):
                continue
            if isinstance(valeur, (tuple, list)):  # ex. hidden_layer_sizes = (64, 32)
                for i, taille in enumerate(valeur, start=1):
                    lignes_metrics.append({"modele": nom, "metrique": f"hp_{nom_param}_couche{i}",
                                           "jeu": "hyperparametres", "valeur": float(taille)})
            elif isinstance(valeur, (int, float)):
                lignes_metrics.append({"modele": nom, "metrique": f"hp_{nom_param}",
                                       "jeu": "hyperparametres", "valeur": float(valeur)})

        print(f"  PR-AUC en CV du meilleur candidat (avant calibration) : "
              f"{res['mean_test_pr_auc'][idx]:.4f}")

        # Modele final = meilleur pipeline + calibration des probabilites.
        # clone() repart d'un pipeline non ajuste : CalibratedClassifierCV le
        # reajuste sur chaque pli interne de calibration.
        final = CalibratedClassifierCV(clone(meilleur), method=methode_calibration,
                                       cv=cv_calibration)

        # Scores CV (moyenne, ecart-type) et train (surapprentissage) du modele final,
        # obtenus par validation croisee externe sur les memes 5 plis
        scores_cv = cross_validate(final, X_train, y_train, cv=cv, scoring=SCORING,
                                   return_train_score=True, n_jobs=-1)
        print("  Scores du modele calibre en validation croisee (moyenne +/- ecart-type) :")
        for metrique in SCORING:
            moy = float(scores_cv[f"test_{metrique}"].mean())
            std = float(scores_cv[f"test_{metrique}"].std())
            train = float(scores_cv[f"train_{metrique}"].mean())
            lignes_metrics += [
                {"modele": nom, "metrique": metrique, "jeu": "cv_moyenne", "valeur": moy},
                {"modele": nom, "metrique": metrique, "jeu": "cv_ecart_type", "valeur": std},
                {"modele": nom, "metrique": metrique, "jeu": "train_moyenne", "valeur": train},
            ]
            print(f"    {metrique:18s} CV = {moy:.4f} +/- {std:.4f}   (train = {train:.4f})")

        # Choix du seuil sur les probabilites calibrees hors pli du train
        proba_oof = cross_val_predict(final, X_train, y_train, cv=cv,
                                      method="predict_proba", n_jobs=-1)[:, 1]
        seuil, fbeta = choisir_seuil(y_train, proba_oof)
        seuils[nom] = seuil
        lignes_metrics.append({"modele": nom, "metrique": "seuil_choisi", "jeu": "cv",
                               "valeur": seuil})
        lignes_metrics.append({"modele": nom, "metrique": "f2_hors_pli_au_seuil", "jeu": "cv",
                               "valeur": fbeta})
        print(f"  Seuil choisi (max F2 hors pli) : {seuil:.3f}")

        # Ajustement du modele final (calibre) sur tout le train, puis evaluation
        # finale sur le jeu de test, au seuil 0.5 et au seuil choisi
        final.fit(X_train, y_train)
        proba_test = final.predict_proba(X_test)[:, 1]
        probas_test[nom] = proba_test
        ligne_resume = {"modele": nom, "reduction": params.get("reduction", "aucune"),
                        "seuil_choisi": round(seuil, 3)}
        for etiquette, s in [("test_seuil_0.5", 0.5), ("test_seuil_choisi", seuil)]:
            m = calculer_metriques(y_test, proba_test, s)
            for metrique, valeur in m.items():
                lignes_metrics.append({"modele": nom, "metrique": metrique, "jeu": etiquette,
                                       "valeur": valeur})
            suffixe = "_0.5" if etiquette == "test_seuil_0.5" else "_seuil"
            for metrique in ["rappel", "precision", "f1", "roc_auc", "pr_auc",
                             "balanced_accuracy", "mcc", "faux_negatifs", "faux_positifs"]:
                ligne_resume[metrique + suffixe] = round(m[metrique], 4)
        resume_test.append(ligne_resume)
        print(f"  Test (seuil 0.5)    : rappel={ligne_resume['rappel_0.5']:.4f} "
              f"precision={ligne_resume['precision_0.5']:.4f} F1={ligne_resume['f1_0.5']:.4f} "
              f"ROC-AUC={ligne_resume['roc_auc_0.5']:.4f} FN={ligne_resume['faux_negatifs_0.5']}")
        print(f"  Test (seuil choisi) : rappel={ligne_resume['rappel_seuil']:.4f} "
              f"precision={ligne_resume['precision_seuil']:.4f} F1={ligne_resume['f1_seuil']:.4f} "
              f"FN={ligne_resume['faux_negatifs_seuil']}")

        # Sauvegarde du modele final (pipeline calibre) et des resultats de la recherche
        modeles_entraines[nom] = final
        joblib.dump(final, os.path.join(DOSSIER_MODELES, f"{nom_fichier(nom)}.joblib"))
        pd.DataFrame(res).drop(columns=["params"]).to_csv(
            chemin_result(f"03_cv_{nom_fichier(nom)}.csv"), index=False)

    # ---- Selection du meilleur modele (PR-AUC moyenne en CV) ----------
    metrics = pd.DataFrame(lignes_metrics)
    cv_pr = metrics[(metrics.metrique == METRIQUE_OPTIMISATION) & (metrics.jeu == "cv_moyenne")]
    cv_roc = metrics[(metrics.metrique == "roc_auc") & (metrics.jeu == "cv_moyenne")]
    classement = (cv_pr.set_index("modele")["valeur"].rename("pr_auc").to_frame()
                  .join(cv_roc.set_index("modele")["valeur"].rename("roc_auc"))
                  .sort_values(["pr_auc", "roc_auc"], ascending=False))
    meilleur_nom = classement.index[0]
    print("\n" + "=" * 70)
    print(f"MEILLEUR MODELE (PR-AUC en CV) : {meilleur_nom}")
    print(classement.round(4).to_string())
    with open(chemin_result("03_meilleur_modele.json"), "w", encoding="utf-8") as f:
        json.dump({"meilleur_modele": meilleur_nom,
                   "critere": "PR-AUC moyenne en validation croisee (5 plis)",
                   "fichier": f"modeles/{nom_fichier(meilleur_nom)}.joblib",
                   "seuil_choisi": seuils[meilleur_nom],
                   "classement": classement.index.tolist()}, f, indent=2, ensure_ascii=False)
    with open(chemin_result("03_meilleurs_hyperparametres.json"), "w", encoding="utf-8") as f:
        json.dump(meilleurs_params, f, indent=2, ensure_ascii=False)

    # ---- Ajout des informations de donnees et d'ACP dans metrics.csv ---
    # (ainsi, chaque chiffre du rapport provient d'un seul fichier)
    for cle in ["n_patients", "n_variables", "n_valeurs_manquantes", "n_benin", "n_malin",
                "pct_malin", "n_paires_corr_sup_0_9"]:
        lignes_metrics.append({"modele": "donnees", "metrique": cle, "jeu": "description",
                               "valeur": description[cle]})
    for cle in ["n_train", "n_test", "n_malin_train", "n_malin_test"]:
        valeur = {"n_train": len(X_train), "n_test": len(X_test),
                  "n_malin_train": int(y_train.sum()), "n_malin_test": int(y_test.sum())}[cle]
        lignes_metrics.append({"modele": "donnees", "metrique": cle, "jeu": "description",
                               "valeur": valeur})
    for cle in ["n_composantes_acp_95", "n_composantes_kaiser", "variance_cumulee_2_composantes",
                "variance_cumulee_n_comp_95"]:
        lignes_metrics.append({"modele": "acp", "metrique": cle, "jeu": "description",
                               "valeur": reduction_info[cle]})
    for cle, liste in [("n_variables_correlation", "variables_correlation"),
                       ("n_variables_lasso", "variables_lasso"),
                       ("n_variables_foret", "variables_foret")]:
        lignes_metrics.append({"modele": "selection", "metrique": cle, "jeu": "description",
                               "valeur": len(reduction_info[liste])})
    for cle in ["lasso_C_1se", "lasso_C_meilleur"]:
        lignes_metrics.append({"modele": "selection", "metrique": cle, "jeu": "description",
                               "valeur": reduction_info[cle]})
    lignes_metrics.append({"modele": "calibration", "metrique": "sigmoide", "jeu": "description",
                           "valeur": float(methode_calibration == "sigmoid")})
    for ligne in reduction_info["comparaison"]:
        for m in ["roc_auc", "average_precision", "recall", "f1"]:
            lignes_metrics.append({"modele": "selection : " + ligne["sous_ensemble"],
                                   "metrique": m, "jeu": "cv_moyenne",
                                   "valeur": ligne[f"{m}_moyenne"]})
            lignes_metrics.append({"modele": "selection : " + ligne["sous_ensemble"],
                                   "metrique": m, "jeu": "cv_ecart_type",
                                   "valeur": ligne[f"{m}_ecart_type"]})

    metrics = pd.DataFrame(lignes_metrics)
    metrics["valeur"] = metrics["valeur"].astype(float).round(6)
    metrics.to_csv(chemin_result("metrics.csv"), index=False)
    pd.DataFrame(resume_test).to_csv(chemin_result("03_resume_test.csv"), index=False)
    print("\nMetriques sauvegardees dans results/metrics.csv")

    # ---- Figures ------------------------------------------------------
    noms_modeles = list(recherches.keys())
    palette = dict(zip(noms_modeles, sns.color_palette("tab10", len(noms_modeles))))

    # Courbes ROC (test)
    fig, ax = plt.subplots(figsize=(6, 5))
    for nom in noms_modeles:
        fpr, tpr, _ = roc_curve(y_test, probas_test[nom])
        auc = roc_auc_score(y_test, probas_test[nom])
        ax.plot(fpr, tpr, color=palette[nom], label=f"{nom_affiche(nom)} (AUC = {auc:.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=0.8, label="Aléatoire")
    ax.set_xlabel("Taux de faux positifs (1 - spécificité)")
    ax.set_ylabel("Taux de vrais positifs (rappel)")
    ax.set_title("Courbes ROC sur le jeu de test")
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    fig.savefig(chemin_figure("03_courbes_roc.png"), dpi=150)
    plt.close(fig)

    # Courbes precision-rappel (test)
    fig, ax = plt.subplots(figsize=(6, 5))
    for nom in noms_modeles:
        prec, rap, _ = precision_recall_curve(y_test, probas_test[nom])
        ap = average_precision_score(y_test, probas_test[nom])
        ax.plot(rap, prec, color=palette[nom], label=f"{nom_affiche(nom)} (PR-AUC = {ap:.3f})")
    ax.axhline(y_test.mean(), color="k", ls="--", lw=0.8,
               label=f"Aléatoire (prévalence = {y_test.mean():.2f})")
    ax.set_xlabel("Rappel")
    ax.set_ylabel("Précision")
    ax.set_title("Courbes précision-rappel sur le jeu de test")
    ax.legend(loc="lower left", fontsize=8)
    fig.tight_layout()
    fig.savefig(chemin_figure("03_courbes_pr.png"), dpi=150)
    plt.close(fig)

    # Matrices de confusion (test, seuil choisi)
    fig, axes = plt.subplots(1, len(noms_modeles), figsize=(3.4 * len(noms_modeles), 3.6))
    for ax, nom in zip(axes, noms_modeles):
        pred = (probas_test[nom] >= seuils[nom]).astype(int)
        ConfusionMatrixDisplay.from_predictions(y_test, pred, ax=ax, colorbar=False,
                                                display_labels=[NOM_CLASSES[0], NOM_CLASSES[1]],
                                                cmap="Blues")
        ax.set_title(f"{nom_affiche(nom)}\n(seuil = {seuils[nom]:.2f})", fontsize=9)
        ax.set_xlabel("Prédit")
        ax.set_ylabel("Réel")
    fig.suptitle("Matrices de confusion sur le jeu de test (seuil optimisé)")
    fig.tight_layout()
    fig.savefig(chemin_figure("03_matrices_confusion.png"), dpi=150)
    plt.close(fig)

    # Comparaison des modeles en CV (moyenne +/- ecart-type)
    metriques_aff = ["rappel", "precision", "f1", "roc_auc", "pr_auc", "balanced_accuracy", "mcc"]
    fig, ax = plt.subplots(figsize=(11, 4.8))
    largeur = 0.8 / len(noms_modeles)
    x = np.arange(len(metriques_aff))
    for i, nom in enumerate(noms_modeles):
        moy = [metrics[(metrics.modele == nom) & (metrics.metrique == m) &
                       (metrics.jeu == "cv_moyenne")]["valeur"].iloc[0] for m in metriques_aff]
        std = [metrics[(metrics.modele == nom) & (metrics.metrique == m) &
                       (metrics.jeu == "cv_ecart_type")]["valeur"].iloc[0] for m in metriques_aff]
        ax.bar(x + (i - (len(noms_modeles) - 1) / 2) * largeur, moy, largeur, yerr=std,
               capsize=2, color=palette[nom], label=nom_affiche(nom))
    ax.set_xticks(x)
    ax.set_xticklabels([m.replace("_", " ").upper() for m in metriques_aff])
    ax.set_ylim(0.8, 1.02)
    ax.set_ylabel("Score (validation croisée, moyenne +/- écart-type)")
    ax.set_title("Comparaison des modèles optimisés en validation croisée (5 plis)")
    ax.legend(loc="lower right", fontsize=8, ncol=3)
    fig.tight_layout()
    fig.savefig(chemin_figure("03_comparaison_cv.png"), dpi=150)
    plt.close(fig)

    # Surapprentissage : score train vs CV vs test (PR-AUC et ROC-AUC)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    for ax, metrique, titre in zip(axes, ["pr_auc", "roc_auc"], ["PR-AUC", "ROC-AUC"]):
        train = [metrics[(metrics.modele == n) & (metrics.metrique == metrique) &
                         (metrics.jeu == "train_moyenne")]["valeur"].iloc[0] for n in noms_modeles]
        cv_m = [metrics[(metrics.modele == n) & (metrics.metrique == metrique) &
                        (metrics.jeu == "cv_moyenne")]["valeur"].iloc[0] for n in noms_modeles]
        test = [metrics[(metrics.modele == n) & (metrics.metrique == metrique) &
                        (metrics.jeu == "test_seuil_0.5")]["valeur"].iloc[0] for n in noms_modeles]
        x = np.arange(len(noms_modeles))
        ax.bar(x - 0.27, train, 0.27, label="Train (moyenne des plis)", color="#8C8C8C")
        ax.bar(x, cv_m, 0.27, label="Validation croisée", color="#4C72B0")
        ax.bar(x + 0.27, test, 0.27, label="Test", color="#C44E52")
        ax.set_xticks(x)
        ax.set_xticklabels([nom_affiche(n).replace(" (MLP)", "\n(MLP)") for n in noms_modeles], fontsize=8)
        ax.set_ylim(0.9, 1.005)
        ax.set_title(f"{titre} : train vs validation vs test")
        ax.legend(fontsize=8, loc="lower right")
    fig.suptitle("Diagnostic de surapprentissage (écart train / validation)")
    fig.tight_layout()
    fig.savefig(chemin_figure("03_surapprentissage.png"), dpi=150)
    plt.close(fig)

    # Choix du seuil pour le meilleur modele : precision, rappel et F2 selon le seuil
    proba_oof = cross_val_predict(modeles_entraines[meilleur_nom], X_train, y_train, cv=cv,
                                  method="predict_proba", n_jobs=-1)[:, 1]
    prec, rap, s = precision_recall_curve(y_train, proba_oof)
    prec, rap = prec[:-1], rap[:-1]
    f2 = 5 * prec * rap / np.maximum(4 * prec + rap, 1e-12)
    fig, ax = plt.subplots(figsize=(7, 4.3))
    ax.plot(s, rap, label="Rappel", color="#C44E52")
    ax.plot(s, prec, label="Précision", color="#4C72B0")
    ax.plot(s, f2, label="F2-score", color="#55A868")
    ax.axvline(seuils[meilleur_nom], ls="--", color="gray",
               label=f"Seuil choisi = {seuils[meilleur_nom]:.2f}")
    ax.axvline(0.5, ls=":", color="black", label="Seuil par défaut = 0.5")
    ax.set_xlabel("Seuil de décision sur la probabilité de malignité")
    ax.set_ylabel("Score (probabilités hors pli, train)")
    ax.set_title(f"Choix du seuil de décision ({nom_affiche(meilleur_nom)})")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(chemin_figure("03_choix_seuil.png"), dpi=150)
    plt.close(fig)

    print("Figures de l'etape 3 sauvegardees.")


if __name__ == "__main__":
    main()
