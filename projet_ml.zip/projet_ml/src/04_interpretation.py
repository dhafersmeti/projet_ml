"""
Etape 4 : interpretation du meilleur modele.

Deux methodes, independantes du type de modele (elles fonctionnent pour un
MLP comme pour une foret) :
  1. Importance par permutation : on melange une variable a la fois dans le
     jeu de test et on mesure la baisse de PR-AUC. Plus la baisse est forte,
     plus la variable est utile au modele. Repete 30 fois pour obtenir une
     moyenne et un ecart-type.
  2. Valeurs de SHAP (SHapley Additive exPlanations) : contribution de chaque
     variable a la probabilite de malignite predite, patient par patient.
     Calculees avec l'explicateur generique par permutation de la librairie
     shap, applique au Pipeline complet (donc sur les variables d'origine).

Sorties :
  figures/04_importance_permutation.png
  figures/04_shap_resume.png (si le calcul SHAP reussit)
  results/04_importance_permutation.csv
  results/metrics.csv (lignes d'importance ajoutees)
"""

import json
import os
import sys
import warnings

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.inspection import permutation_importance

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (DOSSIER_RESULTS, RANDOM_STATE, charger_donnees, chemin_figure, nom_affiche,
                    chemin_result, creer_dossiers, fixer_graines,
                    separer_train_test)

warnings.filterwarnings("ignore")


def importance_permutation(modele, X_test, y_test, noms, nom_modele):
    """Importance par permutation sur le jeu de test (metrique : PR-AUC)."""
    resultat = permutation_importance(modele, X_test, y_test, scoring="average_precision",
                                      n_repeats=30, random_state=RANDOM_STATE, n_jobs=-1)
    importances = pd.DataFrame({"variable": noms,
                                "importance_moyenne": resultat.importances_mean,
                                "importance_ecart_type": resultat.importances_std})
    importances = importances.sort_values("importance_moyenne", ascending=False)
    importances.to_csv(chemin_result("04_importance_permutation.csv"), index=False)

    print("Importance par permutation (baisse de PR-AUC sur le test), 15 premieres :")
    print(importances.head(15).round(4).to_string(index=False))

    top = importances.head(15).iloc[::-1]
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.barh(top["variable"], top["importance_moyenne"], xerr=top["importance_ecart_type"],
            color="#4C72B0", capsize=3)
    ax.axvline(0, color="black", lw=0.8)
    ax.set_xlabel("Baisse moyenne de PR-AUC quand la variable est mélangée (30 répétitions)")
    ax.set_title(f"Importance par permutation (test) : {nom_affiche(nom_modele)}")
    fig.tight_layout()
    fig.savefig(chemin_figure("04_importance_permutation.png"), dpi=150)
    plt.close(fig)
    return importances


def analyse_shap(modele, X_train, X_test, noms, nom_modele):
    """
    Valeurs de SHAP avec l'explicateur par permutation (generique).
    Renvoie True si la figure a ete produite, False sinon.
    """
    try:
        import shap
    except ImportError:
        print("Librairie shap non installee : etape SHAP ignoree.")
        return False
    try:
        # Fonction a expliquer : probabilite de malignite donnee par le Pipeline complet
        def proba_malin(donnees):
            return modele.predict_proba(pd.DataFrame(donnees, columns=noms))[:, 1]

        # Echantillon de reference (train) et echantillon a expliquer (test)
        fond = shap.utils.sample(X_train.values, 100, random_state=RANDOM_STATE)
        explicateur = shap.PermutationExplainer(proba_malin, fond, seed=RANDOM_STATE)
        X_expl = X_test.values
        valeurs = explicateur(X_expl, max_evals=2 * len(noms) + 1)

        fig = plt.figure(figsize=(8, 6))
        shap.summary_plot(valeurs.values, X_expl, feature_names=noms, max_display=15,
                          show=False, plot_size=None)
        plt.title(f"Valeurs de SHAP (test) : {nom_affiche(nom_modele)}\n"
                  "à droite = pousse vers 'malin', couleur = valeur de la variable", fontsize=10)
        plt.tight_layout()
        plt.savefig(chemin_figure("04_shap_resume.png"), dpi=150, bbox_inches="tight")
        plt.close("all")

        # Importance globale SHAP = moyenne des |valeurs| par variable
        imp_shap = pd.Series(np.abs(valeurs.values).mean(axis=0), index=noms)
        imp_shap.sort_values(ascending=False).rename("importance_shap_moyenne_abs").to_csv(
            chemin_result("04_importance_shap.csv"))
        print("\nImportance globale SHAP (moyenne des |SHAP|), 10 premieres :")
        print(imp_shap.sort_values(ascending=False).head(10).round(4).to_string())
        return True
    except Exception as erreur:  # SHAP ne doit jamais faire echouer le pipeline complet
        print(f"Calcul SHAP impossible ({type(erreur).__name__} : {erreur}). Etape ignoree.")
        return False


def main():
    fixer_graines()
    creer_dossiers()
    sns.set_theme(style="whitegrid")

    print("=" * 70)
    print("ETAPE 4 : INTERPRETATION DU MEILLEUR MODELE")
    print("=" * 70)

    X, y, noms = charger_donnees()
    X_train, X_test, y_train, y_test = separer_train_test(X, y)

    with open(chemin_result("03_meilleur_modele.json"), encoding="utf-8") as f:
        info = json.load(f)
    nom_modele = info["meilleur_modele"]
    modele = joblib.load(os.path.join(DOSSIER_RESULTS, info["fichier"]))
    print(f"Meilleur modele : {nom_modele}")
    # Le modele sauvegarde est un CalibratedClassifierCV qui enveloppe le Pipeline
    pipeline = getattr(modele, "estimator", modele)
    if hasattr(pipeline, "steps"):
        print(f"Pipeline calibre ({type(modele).__name__}) : {[nom for nom, _ in pipeline.steps]}")

    importances = importance_permutation(modele, X_test, y_test, noms, nom_modele)
    shap_ok = analyse_shap(modele, X_train, X_test, noms, nom_modele)

    # Ajout des 10 importances principales dans metrics.csv (source unique du rapport)
    metrics = pd.read_csv(chemin_result("metrics.csv"))
    metrics = metrics[~metrics["jeu"].isin(["importance_permutation"])]  # evite les doublons
    lignes = []
    for rang, (_, ligne) in enumerate(importances.head(10).iterrows(), start=1):
        lignes.append({"modele": nom_modele, "metrique": f"importance_{rang:02d}_{ligne['variable']}",
                       "jeu": "importance_permutation",
                       "valeur": round(float(ligne["importance_moyenne"]), 6)})
    lignes.append({"modele": nom_modele, "metrique": "shap_disponible",
                   "jeu": "importance_permutation", "valeur": float(shap_ok)})
    metrics = pd.concat([metrics, pd.DataFrame(lignes)], ignore_index=True)
    metrics.to_csv(chemin_result("metrics.csv"), index=False)
    print("\nImportances ajoutees a results/metrics.csv")


if __name__ == "__main__":
    main()
