"""
Configuration commune a tous les scripts du projet.

Ce module centralise :
  - la graine aleatoire (reproductibilite),
  - les chemins des dossiers de sortie (figures/, results/),
  - le chargement du jeu de donnees Breast Cancer Wisconsin.

Convention importante sur la cible :
  Dans scikit-learn, load_breast_cancer code 0 = tumeur maligne et 1 = benigne.
  Pour un outil d'aide au diagnostic, la classe "positive" doit etre la maladie
  (tumeur maligne), car c'est le faux negatif (cancer manque) qui coute cher.
  On recode donc y = 1 pour MALIN et y = 0 pour BENIN dans tout le projet.
"""

import os
import random

import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer

# Graine aleatoire unique pour tout le projet
RANDOM_STATE = 42

# Dossiers du projet (calcules par rapport a ce fichier, donc independants du
# repertoire depuis lequel on lance les scripts)
RACINE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOSSIER_FIGURES = os.path.join(RACINE, "figures")
DOSSIER_RESULTS = os.path.join(RACINE, "results")
DOSSIER_MODELES = os.path.join(DOSSIER_RESULTS, "modeles")

# Noms lisibles des classes apres recodage
NOM_CLASSES = {0: "Bénin", 1: "Malin"}

# Les noms de modeles servent de cles (sans accent) dans results/metrics.csv ;
# cette table donne leur version accentuee pour les figures et le rapport.
NOMS_AFFICHES = {
    "Regression logistique": "Régression logistique",
    "Random Forest": "Random Forest",
    "Gradient Boosting": "Gradient Boosting",
    "XGBoost": "XGBoost",
    "Reseau de neurones (MLP)": "Réseau de neurones (MLP)",
}


def nom_affiche(nom_modele: str) -> str:
    """Version accentuee d'un nom de modele (pour l'affichage uniquement)."""
    return NOMS_AFFICHES.get(nom_modele, nom_modele)


def fixer_graines(seed: int = RANDOM_STATE) -> None:
    """Fixe toutes les graines aleatoires utilisees (random, numpy, hash Python)."""
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)


def creer_dossiers() -> None:
    """Cree les dossiers de sortie s'ils n'existent pas."""
    for dossier in (DOSSIER_FIGURES, DOSSIER_RESULTS, DOSSIER_MODELES):
        os.makedirs(dossier, exist_ok=True)


def charger_donnees():
    """
    Charge le jeu de donnees et renvoie (X, y, noms_variables).

    X : DataFrame (569 lignes x 30 colonnes) avec les noms de variables d'origine
    y : Series d'entiers, 1 = tumeur maligne (classe positive), 0 = benigne
    """
    donnees = load_breast_cancer()
    X = pd.DataFrame(donnees.data, columns=donnees.feature_names)
    # Recodage : scikit-learn met 0 = malin ; on veut 1 = malin
    y = pd.Series(1 - donnees.target, name="malin")
    return X, y, [str(nom) for nom in donnees.feature_names]


def separer_train_test(X, y, test_size: float = 0.2):
    """
    Separation train / test stratifiee, identique dans tous les scripts.

    Le jeu de test (20 %) est mis de cote des le depart et n'est utilise
    qu'une seule fois, pour l'evaluation finale. La stratification conserve
    la meme proportion de tumeurs malignes dans les deux sous-ensembles.
    """
    from sklearn.model_selection import train_test_split

    return train_test_split(X, y, test_size=test_size, stratify=y,
                            random_state=RANDOM_STATE)


def chemin_figure(nom_fichier: str) -> str:
    """Chemin complet d'une figure dans figures/."""
    return os.path.join(DOSSIER_FIGURES, nom_fichier)


def chemin_result(nom_fichier: str) -> str:
    """Chemin complet d'un fichier de resultats dans results/."""
    return os.path.join(DOSSIER_RESULTS, nom_fichier)
