"""
Cree l'archive de rendu PRENOM_NOM_GROUPE_Sujet3.zip.

Le script demande le prenom, le nom et le groupe (ou les lit sur la ligne de
commande : --prenom, --nom, --groupe), puis archive :
    src/ (fichiers .py uniquement), main.py, make_zip.py, requirements.txt,
    rapport.docx, references.md, CONSIGNES.md, figures/, results/
Les notebooks (.ipynb), caches Python et modeles .joblib volumineux sont exclus.

Usage : python make_zip.py
        python make_zip.py --prenom Prenom --nom Nom --groupe G1
"""

import argparse
import os
import re
import sys
import unicodedata
import zipfile

RACINE = os.path.dirname(os.path.abspath(__file__))

FICHIERS = ["main.py", "make_zip.py", "requirements.txt", "rapport.docx", "references.md",
            "CONSIGNES.md"]
DOSSIERS = ["src", "figures", "results"]
EXTENSIONS_EXCLUES = {".ipynb", ".pyc", ".joblib"}
DOSSIERS_EXCLUS = {"__pycache__", ".ipynb_checkpoints"}


def normaliser(texte: str) -> str:
    """Majuscules, sans accents, sans espaces ni caracteres speciaux (pour un nom de fichier)."""
    texte = unicodedata.normalize("NFKD", texte).encode("ascii", "ignore").decode()
    texte = re.sub(r"[^A-Za-z0-9]+", "_", texte.strip())
    return texte.strip("_").upper()


def demander(question: str) -> str:
    """Pose une question jusqu'a obtenir une reponse non vide."""
    while True:
        reponse = input(question).strip()
        if reponse:
            return reponse
        print("  Reponse vide, merci de reessayer.")


def main():
    parseur = argparse.ArgumentParser(description="Cree l'archive de rendu du sujet 3.")
    parseur.add_argument("--prenom", help="prenom de l'etudiant (demande si absent)")
    parseur.add_argument("--nom", help="nom de l'etudiant (demande si absent)")
    parseur.add_argument("--groupe", help="groupe (demande si absent)")
    args = parseur.parse_args()

    print("Creation de l'archive de rendu (Sujet 3)")
    # Chaque information vient de la ligne de commande si elle est fournie, sinon on la demande
    prenom = normaliser(args.prenom or demander("Prenom : "))
    nom = normaliser(args.nom or demander("Nom : "))
    groupe = normaliser(args.groupe or demander("Groupe : "))
    nom_zip = f"{prenom}_{nom}_{groupe}_Sujet3.zip"
    chemin_zip = os.path.join(RACINE, nom_zip)

    # Verification que tout a bien ete genere (sinon lancer main.py d'abord)
    manquants = [f for f in FICHIERS + DOSSIERS if not os.path.exists(os.path.join(RACINE, f))]
    if manquants:
        print(f"ERREUR : elements manquants : {manquants}. Lancez d'abord 'python main.py'.")
        sys.exit(1)

    n_fichiers = 0
    with zipfile.ZipFile(chemin_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for fichier in FICHIERS:
            zf.write(os.path.join(RACINE, fichier), fichier)
            n_fichiers += 1
        for dossier in DOSSIERS:
            for racine_dossier, sous_dossiers, fichiers in os.walk(os.path.join(RACINE, dossier)):
                # On ne descend pas dans les dossiers exclus
                sous_dossiers[:] = [d for d in sous_dossiers if d not in DOSSIERS_EXCLUS]
                for fichier in fichiers:
                    if os.path.splitext(fichier)[1].lower() in EXTENSIONS_EXCLUES:
                        continue
                    chemin = os.path.join(racine_dossier, fichier)
                    zf.write(chemin, os.path.relpath(chemin, RACINE))
                    n_fichiers += 1

    taille_mo = os.path.getsize(chemin_zip) / 1e6
    print(f"\nArchive creee : {chemin_zip}")
    print(f"{n_fichiers} fichiers, {taille_mo:.1f} Mo")


if __name__ == "__main__":
    main()
