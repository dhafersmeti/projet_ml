# References

Projet : aide au diagnostic medical via la modelisation de donnees tabulaires (sujet n 3).

## Jeu de donnees

1. Wolberg, W., Mangasarian, O., Street, N. et Street, W. (1995). *Breast Cancer Wisconsin (Diagnostic)*. UCI Machine Learning Repository. https://doi.org/10.24432/C5DW2B
2. Street, W. N., Wolberg, W. H. et Mangasarian, O. L. (1993). Nuclear feature extraction for breast tumor diagnosis. *Proceedings of SPIE 1905, Biomedical Image Processing and Biomedical Visualization*, p. 861 a 870. (Article decrivant l'extraction des 30 descripteurs a partir des images de cytoponction.)
3. Documentation scikit-learn, `sklearn.datasets.load_breast_cancer` : https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_breast_cancer.html

## Methodes et documentation scikit-learn (code)

4. Pipeline et prevention des fuites de donnees : https://scikit-learn.org/stable/modules/compose.html et https://scikit-learn.org/stable/common_pitfalls.html#data-leakage
5. Standardisation `StandardScaler` : https://scikit-learn.org/stable/modules/preprocessing.html
6. Analyse en composantes principales `PCA` : https://scikit-learn.org/stable/modules/decomposition.html#pca
7. Selection de variables (`SelectFromModel`, penalite L1, importance par arbres) : https://scikit-learn.org/stable/modules/feature_selection.html
8. Regression logistique (`LogisticRegression`, `LogisticRegressionCV`) : https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
9. Forets aleatoires et gradient boosting (`RandomForestClassifier`, `GradientBoostingClassifier`) : https://scikit-learn.org/stable/modules/ensemble.html
10. Reseau de neurones multicouche `MLPClassifier` et arret precoce : https://scikit-learn.org/stable/modules/neural_networks_supervised.html
11. Validation croisee stratifiee `StratifiedKFold`, `cross_validate`, `cross_val_predict` : https://scikit-learn.org/stable/modules/cross_validation.html
12. Optimisation des hyperparametres `GridSearchCV` et `RandomizedSearchCV` : https://scikit-learn.org/stable/modules/grid_search.html
13. Metriques de classification (rappel, precision, F1, ROC-AUC, average precision, balanced accuracy, MCC, matrice de confusion) : https://scikit-learn.org/stable/modules/model_evaluation.html
14. Importance par permutation `permutation_importance` : https://scikit-learn.org/stable/modules/permutation_importance.html
14b. Calibration des probabilites `CalibratedClassifierCV` (sigmoide de Platt, isotonique) : https://scikit-learn.org/stable/modules/calibration.html
15. Documentation XGBoost (interface scikit-learn `XGBClassifier`) : https://xgboost.readthedocs.io/en/stable/python/sklearn_estimator.html
16. Documentation SHAP (`PermutationExplainer`, `summary_plot`) : https://shap.readthedocs.io/
17. Documentation python-docx (generation du rapport) : https://python-docx.readthedocs.io/
18. Documentation matplotlib et seaborn (figures) : https://matplotlib.org/stable/ et https://seaborn.pydata.org/

## Articles et ouvrages

19. Pedregosa, F. et al. (2011). Scikit-learn: Machine Learning in Python. *Journal of Machine Learning Research*, 12, p. 2825 a 2830.
20. Chen, T. et Guestrin, C. (2016). XGBoost: A Scalable Tree Boosting System. *Proceedings of the 22nd ACM SIGKDD*, p. 785 a 794.
21. Breiman, L. (2001). Random Forests. *Machine Learning*, 45(1), p. 5 a 32.
22. Lundberg, S. M. et Lee, S.-I. (2017). A Unified Approach to Interpreting Model Predictions. *Advances in Neural Information Processing Systems 30 (NIPS)*.
23. Tibshirani, R. (1996). Regression Shrinkage and Selection via the Lasso. *Journal of the Royal Statistical Society, Series B*, 58(1), p. 267 a 288.
24. Saito, T. et Rehmsmeier, M. (2015). The Precision-Recall Plot Is More Informative than the ROC Plot When Evaluating Binary Classifiers on Imbalanced Datasets. *PLoS ONE*, 10(3), e0118432.
25. Chicco, D. et Jurman, G. (2020). The advantages of the Matthews correlation coefficient (MCC) over F1 score and accuracy in binary classification evaluation. *BMC Genomics*, 21, 6.
25b. Platt, J. (1999). Probabilistic outputs for support vector machines and comparisons to regularized likelihood methods. Dans *Advances in Large Margin Classifiers*, MIT Press, p. 61 a 74. (Calibration sigmoide utilisee avant le choix du seuil.)
26. Prechelt, L. (1998). Early Stopping, but when? Dans *Neural Networks: Tricks of the Trade*, Springer, p. 55 a 69.
27. Hannun, A. Y. et al. (2019). Cardiologist-level arrhythmia detection and classification in ambulatory electrocardiograms using a deep neural network. *Nature Medicine*, 25, p. 65 a 69. (Reference pour la perspective d'extension aux signaux ECG.)
28. Moody, G. B. et Mark, R. G. (2001). The impact of the MIT-BIH Arrhythmia Database. *IEEE Engineering in Medicine and Biology Magazine*, 20(3), p. 45 a 50. (Jeu de donnees ECG de reference, disponible sur PhysioNet.)

## Origine du code

Versions utilisees pour produire les resultats du rapport : Python 3.12.10, numpy 2.5.4, pandas 3.1.0, scipy 1.18.1, scikit-learn 1.9.1, xgboost 3.4.1, shap 0.54.1, matplotlib 3.11.2, seaborn 0.13.2, joblib 1.6.0, python-docx 1.2.0 (voir requirements.txt).

Le code de ce projet a ete ecrit pour ce mini-projet a partir des exemples de la documentation officielle des librairies citees ci-dessus (scikit-learn, XGBoost, SHAP, matplotlib, seaborn, python-docx). Aucun bloc de code n'a ete copie d'un depot tiers.
