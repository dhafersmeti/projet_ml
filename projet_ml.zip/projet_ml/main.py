"""
Point d'entree du projet : lance toutes les etapes dans l'ordre.

    python main.py              -> toutes les etapes (EDA, reduction, modeles,
                                   interpretation, rapport)
    python main.py --sans-rapport  -> toutes les etapes sauf la generation du rapport

Chaque etape est un script independant dans src/, execute dans un processus
separe (ce qui garantit des graines aleatoires propres a chaque etape et un
arret clair si une etape echoue).
"""

import os
import subprocess
import sys
import time

RACINE = os.path.dirname(os.path.abspath(__file__))
DOSSIER_SRC = os.path.join(RACINE, "src")

ETAPES = [
    ("01_eda.py", "Exploration des donnees"),
    ("02_reduction.py", "Reduction de dimensionnalite et selection de variables"),
    ("03_modeles.py", "Modelisation, optimisation et evaluation"),
    ("04_interpretation.py", "Interpretation du meilleur modele"),
    ("05_rapport.py", "Generation du rapport Word"),
]


def lancer_etape(script: str, description: str) -> float:
    """Execute un script de src/ et renvoie sa duree en secondes. Arrete tout en cas d'erreur."""
    chemin = os.path.join(DOSSIER_SRC, script)
    print("\n" + "#" * 70)
    print(f"# {description}  ({script})")
    print("#" * 70, flush=True)
    debut = time.time()
    # Encodage UTF-8 force pour un affichage correct des accents sous Windows
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    resultat = subprocess.run([sys.executable, chemin], cwd=RACINE, env=env)
    duree = time.time() - debut
    if resultat.returncode != 0:
        print(f"\nERREUR : l'etape {script} a echoue (code {resultat.returncode}). Arret.")
        sys.exit(resultat.returncode)
    print(f"\n-> {script} termine en {duree:.0f} s")
    return duree


def main():
    sans_rapport = "--sans-rapport" in sys.argv
    debut_total = time.time()
    for script, description in ETAPES:
        if sans_rapport and script == "05_rapport.py":
            continue
        lancer_etape(script, description)
    print("\n" + "=" * 70)
    print(f"Toutes les etapes ont reussi en {time.time() - debut_total:.0f} s.")
    print("Resultats : results/   Figures : figures/   Rapport : rapport.docx")
    print("=" * 70)


if __name__ == "__main__":
    main()
